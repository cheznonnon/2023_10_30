//
//  AppDelegate.h
//  Nonnon Typing
//
//  Created by のんのん on 2023/08/18.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

