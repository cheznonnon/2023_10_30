// Nonon Freecell
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism] : terminology
//
//	[ Stock ]
//
//	+ upper-right corner
//	+ place where stack A to K
//
//	[ Freecell ]
//
//	+ upper-left corner
//	+ 4 cards only puttable
//
//	[ Tableau ]
//
//	+ main play area




//#define N_MEMORY_DEBUG




#include "../../nonnon/game/chara.c"
#include "../../nonnon/game/transition.c"


#include "../../nonnon/project/cardgenerator/cardgenerator.c"




//#define N_FREECELL_DEBUG_FOUNDATION




// Constants

#ifndef N_GAMECONSOLE

#define N_GAMECONSOLE_ICON_OFFSET_FREECELL ( 1 )

#endif // #ifndef N_GAMECONSOLE


#define NFREECELL_WAV_MUTE         "N_PROJECT_SOUND_MUTE"
#define NFREECELL_WAV_TAKE         "N_PROJECT_SOUND_CLICK"
#define NFREECELL_WAV_DONE         "N_PROJECT_SOUND_GET"

#define N_FREECELL_NOTHING         ( -1 )

#define N_FREECELL_SUIT_HEARTS     N_CARDGENERATOR_SUIT_HEARTS
#define N_FREECELL_SUIT_DIAMONDS   N_CARDGENERATOR_SUIT_DIAMONDS
#define N_FREECELL_SUIT_SPADES     N_CARDGENERATOR_SUIT_SPADES
#define N_FREECELL_SUIT_CLUBS      N_CARDGENERATOR_SUIT_CLUBS
#define N_FREECELL_SUIT_MAX        N_CARDGENERATOR_SUIT_MAX

#define N_FREECELL_CARD_UNIT       N_CARDGENERATOR_CARD_UNIT
#define N_FREECELL_CARD_ALL        N_CARDGENERATOR_CARD_ALL
#define N_FREECELL_PILE_SX         ( 8 )
#define N_FREECELL_PILE_SY         ( N_FREECELL_CARD_UNIT * 2 )
#define N_FREECELL_PILE_ALL        ( N_FREECELL_PILE_SX * N_FREECELL_PILE_SY )
#define N_FREECELL_TABLEAU         ( N_FREECELL_SUIT_MAX + N_FREECELL_PILE_ALL )

#define N_FREECELL_FADE_MSEC       ( 777 )

#define N_FREECELL_DEAL_PHASE_0    0
#define N_FREECELL_DEAL_PHASE_1    1
#define N_FREECELL_DEAL_PHASE_2    2

#define N_FREECELL_RESZ_PHASE_NONE 0
#define N_FREECELL_RESZ_PHASE_STOP 1

#define N_FREECELL_WATCHER_L       0
#define N_FREECELL_WATCHER_R       1

#define N_FREECELL_TIMER_ID_STYLE  ( 1 )

#define N_FREECELL_ANIMATION_STEP     ( 12 )
#define N_FREECELL_ANIMATION_INTERVAL ( 20 )

#define N_FREECELL_SHADOW_COUNT    ( N_FREECELL_SUIT_MAX + 1 )




typedef struct {

	NonnonGame       *self;
	NSOperationQueue *queue;
	n_bmp             canvas;
	BOOL              refresh;
	n_posix_bool      doubleclick;
	n_type_gfx        sx;
	n_type_gfx        sy;

	n_posix_bool      is_init;

	n_posix_bool      is_first;

	n_cardgenerator   cardgen;

	u32               color_bg;
	u32               color_gradient_upper;
	u32               color_gradient_lower;
	u32               color_halo_focus;
	u32               color_halo_current;

	n_posix_bool      splash_onoff;

	n_posix_bool      is_done;

	n_bmp             bmp_bg;
	n_bmp             bmp_freecell;
	n_bmp             bmp_stock[ N_FREECELL_SUIT_MAX ];
	n_bmp             bmp_neko_l, bmp_neko_r;

	n_posix_bool      transition_onoff;
	n_bmp             transition_bmp_old;
	n_bmp             transition_bmp_new;
	double            transition_percent;

	n_posix_bool      animation_onoff;
	int               animation_index_f;
	int               animation_index_t;
	n_type_real       animation_base_x;
	n_type_real       animation_base_y;
	n_type_real       animation_step_x;
	n_type_real       animation_step_y;
	int               animation_server[ N_FREECELL_SUIT_MAX ];

	n_posix_bool      redraw  [ N_FREECELL_PILE_SX  ];
	n_game_chara      freecell[ N_FREECELL_SUIT_MAX ];
	n_game_chara      stock   [ N_FREECELL_SUIT_MAX ];
	n_game_chara      tableau [ N_FREECELL_TABLEAU  ];
	n_game_chara      bottom  [ N_FREECELL_PILE_SX  ];
	n_game_chara      restore [ N_FREECELL_PILE_SY  ];
	int               drag_index;
	int               restore_count;
	int               freespace;

	int               shuffle[ N_FREECELL_CARD_ALL ];

	int               watcher;

	n_posix_bool      shadow_global_onoff;
	n_posix_bool      shadow_onoff;
	n_bmp            *shadow_bmp;
	n_bmp             shadow_bmp_cache[ N_FREECELL_SHADOW_COUNT ];
	n_type_gfx        shadow_x;
	n_type_gfx        shadow_y;
	n_type_gfx        shadow_sx;
	n_type_gfx        shadow_sy;
	n_type_gfx        shadow_px;
	n_type_gfx        shadow_py;
	n_type_gfx        shadow_psx;
	n_type_gfx        shadow_psy;

	n_posix_bool      debug_onoff;
	int               debug_automove_count;

} n_freecell;




#define N_FREECELL_SOUND_CLICK   ( 1 )
#define N_FREECELL_SOUND_FANFARE ( 2 )

// [!] : this is important to play
AVAudioPlayer *n_freecell_snd_click   = NULL;
AVAudioPlayer *n_freecell_snd_fanfare = NULL;

void
n_freecell_sound_play( n_freecell *p, int id )
{

	if ( id == N_FREECELL_SOUND_CLICK )
	{
		//n_freecell_snd_click.delegate = p->self;
		n_mac_sound_play( n_freecell_snd_click );
	} else
	if ( id == N_FREECELL_SOUND_FANFARE )
	{
		//n_freecell_snd_fanfare.delegate = p->self;
		n_mac_sound_play( n_freecell_snd_fanfare );
	}


	return;
}




BOOL
n_mac_is_hovered_offset( n_freecell *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy )
{

	n_posix_bool ret = n_posix_false;

	NSPoint pt = n_game_chara_cursor_position;

	if (
		( ( pt.x > x )&&( pt.x < ( x + sx ) ) )
		&&
		( ( pt.y > y )&&( pt.y < ( y + sy ) ) )
	)
	{
		ret = n_posix_true;
	}

	return ret;
}




#define n_freecell_pos2index( x, y ) ( N_FREECELL_SUIT_MAX + ( x ) + ( N_FREECELL_PILE_SX * ( y ) ) )

#define n_freecell_index_upper( i ) ( ( i ) * N_FREECELL_PILE_SX )

void
n_freecell_pile_count( n_freecell *p, int redraw_map[ N_FREECELL_PILE_SX ] )
{

	int x = 0;
	n_posix_loop
	{

		redraw_map[ x ] = 0;

		int y = 0;
		n_posix_loop
		{

			int target = n_freecell_pos2index( x, y );
			n_game_chara *c = &p->tableau[ target ];

			if ( c->data == N_FREECELL_NOTHING ) { break; }

			//if ( p->redraw[ x ] )
			{
				redraw_map[ x ]++;
			}

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}

		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return;
}

void
n_freecell_redraw( n_freecell *p )
{

	int x = 0;
	n_posix_loop
	{

		p->redraw[ x ] = n_posix_true;

		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return;
}

void
n_freecell_chara_erase( n_freecell *p, n_game_chara *c )
{

	const n_type_gfx m  = p->cardgen.halo;
	const n_type_gfx mm = ( p->cardgen.halo * 2 ) + ( p->cardgen.halo % 2 );


	c->px -= m;
	c->py -= m;
	c->sx += mm;
	c->sy += mm;

	n_game_chara_erase( c );

	c->px += m;
	c->py += m;
	c->sx -= mm;
	c->sy -= mm;


	return;
}

void
n_freecell_chara_draw( n_freecell *p, n_game_chara *c )
{

	if ( p->animation_onoff == n_posix_false )
	{

		n_type_gfx x = c->x - p->cardgen.halo;
		n_type_gfx y = c->y - p->cardgen.halo;

		n_bmp_rasterizer
		(
			&p->cardgen.bmp_halo, &p->canvas, x,y, 
			p->color_halo_current,
			n_posix_false
		);

	}


	n_game_chara_draw( c );


	return;
}

void
n_freecell_shadow( n_freecell *p )
{

	if ( p->shadow_global_onoff == n_posix_false ) { return; }

	//if ( p->animation_onoff ) { return; }


	int index = 0;
	if ( p->restore_count >= 1 ) { index = p->restore_count - 1; }

//n_game_hwndprintf_literal( " %d %d : %d %d ", p->animation_onoff, p->drag_index, p->restore_count, index );


	p->shadow_bmp = &p->shadow_bmp_cache[ index ];

	if ( NULL != N_BMP_PTR( p->shadow_bmp ) )
	{
		return;
	}


	if ( p->drag_index < 0 ) { return; }
	n_game_chara *c = &p->tableau[ p->drag_index ];

	n_type_gfx osy = 0; if ( p->restore_count >= 2 ) { osy = p->cardgen.osy * ( p->restore_count - 1 ); }

//n_game_hwndprintf_literal( " %d ", p->cardgen.halo );

	p->shadow_x  = c->x + ( p->cardgen.halo * 2 );
	p->shadow_y  = c->y + ( p->cardgen.halo * 2 );
	p->shadow_sx = c->sx;
	p->shadow_sy = c->sy + osy;

	n_bmp bmp_tmp; n_bmp_zero( &bmp_tmp );
	n_cardgenerator_dropshadow( &bmp_tmp, p->shadow_sx, p->shadow_sy, p->cardgen.halo, p->cardgen.halo / 2 );

	n_bmp_new_fast( p->shadow_bmp, N_BMP_SX( &bmp_tmp ),N_BMP_SY( &bmp_tmp ) );
	n_bmp_flush( p->shadow_bmp, n_bmp_black_invisible );

	u32 shadow_color = n_bmp_blend_pixel( p->color_gradient_upper, n_bmp_black_invisible, 0.5 );
	n_bmp_rasterizer( &bmp_tmp, p->shadow_bmp, 0,0, shadow_color, n_posix_false );
//n_bmp_save_literal( p->shadow_bmp, "ret.bmp" );

	n_bmp_free_fast( &bmp_tmp );


	return;
}

void
n_freecell_shadow_erase( n_freecell *p )
{

	if ( p->shadow_global_onoff == n_posix_false ) { return; }

	//if ( p->animation_onoff ) { return; }

	if ( p->shadow_onoff == n_posix_false ) { return; }


	p->shadow_onoff = n_posix_false;


	n_type_gfx  x = p->shadow_px;
	n_type_gfx  y = p->shadow_py;
	n_type_gfx sx = p->shadow_psx;
	n_type_gfx sy = p->shadow_psy;

//n_bmp_box( &game.bmp, x,y,sx,sy, n_bmp_rgb(0,200,255) );
	n_bmp_fastcopy( &p->bmp_bg, &p->canvas, x,y,sx,sy, x,y );


	n_game_chara a; n_game_chara_zero( &a );
	n_game_chara_pos( &a, x,y );
	n_game_chara_src( &a, 0,0, sx,sy, 0,0 );

	n_type_gfx ix = 0;
	n_type_gfx iy = 0;
	n_posix_loop
	{//break;

		int target = n_freecell_pos2index( ix, iy );
		n_game_chara *b = &p->tableau[ target ];

		if ( n_game_chara_is_hit( &a, b ) )
		{
			p->redraw[ ix ] = n_posix_true;
		}

		ix++;
		if ( ix >= N_FREECELL_PILE_SX )
		{

			ix = 0;

			iy++;
			if ( iy >= N_FREECELL_PILE_SY ) { break; }
		}
	}


	return;
}

void
n_freecell_shadow_draw( n_freecell *p )
{

	if ( p->shadow_global_onoff == n_posix_false ) { return; }

	//if ( p->animation_onoff ) { return; }


	p->shadow_onoff = n_posix_true;

	n_game_chara *c = &p->tableau[ p->drag_index ];

	n_type_gfx ox = ( p->cardgen.halo * 1 );
	n_type_gfx oy = ( p->cardgen.halo * 1 );
	n_type_gfx  x = c->x + ox;
	n_type_gfx  y = c->y + oy;
	n_type_gfx sx = N_BMP_SX( p->shadow_bmp );
	n_type_gfx sy = N_BMP_SY( p->shadow_bmp );

	//n_bmp_rasterizer( p->shadow_bmp, &game.bmp, x,y, n_bmp_rgb( 50,50,50 ), n_false );
	//n_bmp_transcopy( p->shadow_bmp, &game.bmp, 0,0,sx,sy, x,y );

	n_bmp_clipcopy( p->shadow_bmp, &p->canvas, 0,0,sx,sy, x,y, c->chara,ox,oy, 0.0 );
//n_bmp_save_literal( c->chara, "ret.bmp" );


	p->shadow_px  = x;
	p->shadow_py  = y;
	p->shadow_psx = N_BMP_SX( p->shadow_bmp );
	p->shadow_psy = N_BMP_SY( p->shadow_bmp );


	return;
}

void
n_freecell_animation_go( n_freecell *p, int index_f, int index_t )
{

	p->animation_onoff   = n_posix_true;
	p->animation_index_f = index_f;
	p->animation_index_t = index_t;
	p->animation_base_x  = p->tableau[ index_f ].x;
	p->animation_base_y  = p->tableau[ index_f ].y;

	n_type_real step = N_FREECELL_ANIMATION_STEP;
	p->animation_step_x  = (n_type_real) ( p->stock[ index_t ].x - p->tableau[ index_f ].x ) / step;
	p->animation_step_y  = (n_type_real) ( p->stock[ index_t ].y - p->tableau[ index_f ].y ) / step;

	p->drag_index        = p->animation_index_f;


	p->restore_count     = 0;

	n_freecell_shadow( p );


//p->debug_automove_count++;

	return;
}

void
n_freecell_redraw_detect( n_freecell *p )
{

	n_game_chara card = p->tableau[ p->drag_index ];
//n_game_hwndprintf_literal( " %d ", p->drag_index );

	card.x = card.px;
	card.y = card.py;


	int x = 0;
	int y = 0;
	n_posix_loop
	{

		if ( y == 0 )
		{

			n_game_chara *b = &p->bottom[ x ];
			if ( n_game_chara_is_hit_offset( &card, b, -p->cardgen.halo,-p->cardgen.halo, 0,0 ) )
			{
//n_game_hwndprintf_literal( " 1 " );
				p->redraw[ x ] = n_posix_true;
			}

		} else {

			if ( ( x == p->drag_index )&&( p->restore_count != 0 ) )
			{
//n_game_hwndprintf_literal( " 2 " );

				p->redraw[ x ] = n_posix_true;

			} else {

				int target = n_freecell_pos2index( x, y );
				n_game_chara *c = &p->tableau[ target ];

				if (
					( c->data != N_FREECELL_NOTHING )
					&&
					( n_game_chara_is_hit_offset( &card, c, -p->cardgen.halo,-p->cardgen.halo, 0,0 ) )
				)
				{
//n_game_hwndprintf_literal( " 3 " );
					p->redraw[ x ] = n_posix_true;
				}

			}

		}


		x++;
		if ( x >= N_FREECELL_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}
	}


	return;
}

void
n_freecell_reposition( n_freecell *p )
{

	// Reset : when resized

	int x,y;


	x = 0;
	n_posix_loop
	{

		n_game_chara *c;


		c = &p->freecell[ x ];

		n_game_chara_pos( c, p->cardgen.card_sx * x, 0 );
		n_game_chara_prv( c );


		c = &p->tableau[ x ];

		n_game_chara_pos( c, p->cardgen.card_sx * x, 0 );
		n_game_chara_prv( c );


		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	x = 0;
	n_posix_loop
	{
		n_game_chara *c = &p->stock[ x ];

		n_game_chara_pos( c, p->cardgen.csx - ( p->cardgen.card_sx * 4 ) + ( p->cardgen.card_sx * x ), 0 );
		n_game_chara_prv( c );

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	n_type_gfx tmp_sx = p->cardgen.csx / N_FREECELL_PILE_SX;
	if ( tmp_sx > p->cardgen.card_sx )
	{
		p->cardgen.osx = (n_type_gfx) ( fmod( tmp_sx, p->cardgen.card_sx ) / 2 );
	} else {
		p->cardgen.osx = 0;
	}

//n_game_hwndprintf_literal( "%d : %d %d", p->cardgen.osx, p->cardgen.csx, p->cardgen.card_sx );
//n_game_hwndprintf_literal( "%d %d", ( p->cardgen.csx / N_FREECELL_PILE_SX ), fmod( ( p->cardgen.csx / N_FREECELL_PILE_SX ), p->cardgen.card_sx ) );

	x = 0;
	y = 0;
	n_posix_loop
	{

		int target = n_freecell_pos2index( x,y );

		n_game_chara *c = &p->tableau[ target ];


		n_type_gfx tx = ( ( p->cardgen.osx + p->cardgen.card_sx + p->cardgen.osx ) * x ) + p->cardgen.osx;
		n_type_gfx ty = p->cardgen.card_sy + ( p->cardgen.osy * y );

		n_game_chara_pos( c, tx,ty );
		n_game_chara_prv( c );


		x++;
		if ( x >= N_FREECELL_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}
	}

	x = 0;
	n_posix_loop
	{

		n_game_chara *c = &p->bottom[ x ];


		n_type_gfx tx = ( ( p->cardgen.osx + p->cardgen.card_sx + p->cardgen.osx ) * x ) + p->cardgen.osx;

		n_game_chara_pos( c, tx,p->cardgen.card_sy );
		n_game_chara_prv( c );


		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return;
}

#define n_freecell_rule_is_hearts(   p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_HEARTS,   N_FREECELL_SUIT_DIAMONDS )
#define n_freecell_rule_is_diamonds( p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_DIAMONDS, N_FREECELL_SUIT_SPADES   )
#define n_freecell_rule_is_spades(   p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_SPADES,   N_FREECELL_SUIT_CLUBS    )
#define n_freecell_rule_is_clubs(    p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_CLUBS,    N_FREECELL_SUIT_MAX      )
#define n_freecell_rule_is_reds(     p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_HEARTS,   N_FREECELL_SUIT_SPADES   )
#define n_freecell_rule_is_blacks(   p, i ) n_freecell_rule_range( p, i, N_FREECELL_SUIT_SPADES,   N_FREECELL_SUIT_MAX      )

n_posix_bool
n_freecell_rule_range( n_freecell *p, int index, int f, int t )
{

	int data = p->tableau[ index ].data;
	int unit = N_FREECELL_CARD_UNIT;

	if ( ( data >= ( unit * f ) )&&( data < ( unit * t ) ) ) { return n_posix_true; }


	return n_posix_false;
}

n_posix_bool
n_freecell_rule_suit_is_ok( n_freecell *p, int a, int b )
{

	if ( ( n_freecell_rule_is_hearts  ( p, a ) ) && ( n_freecell_rule_is_hearts  ( p, b ) ) ) { return n_posix_true; }
	if ( ( n_freecell_rule_is_diamonds( p, a ) ) && ( n_freecell_rule_is_diamonds( p, b ) ) ) { return n_posix_true; }
	if ( ( n_freecell_rule_is_spades  ( p, a ) ) && ( n_freecell_rule_is_spades  ( p, b ) ) ) { return n_posix_true; }
	if ( ( n_freecell_rule_is_clubs   ( p, a ) ) && ( n_freecell_rule_is_clubs   ( p, b ) ) ) { return n_posix_true; }


	return n_posix_false;
}

n_posix_bool
n_freecell_rule_half_is_ok( n_freecell *p, int a, int b )
{

	if ( ( n_freecell_rule_is_reds(   p, a ) ) && ( n_freecell_rule_is_blacks( p, b ) ) ) { return n_posix_true; }
	if ( ( n_freecell_rule_is_blacks( p, a ) ) && ( n_freecell_rule_is_reds  ( p, b ) ) ) { return n_posix_true; }


	return n_posix_false;
}

n_posix_bool
n_freecell_rule_rank_is_ok( n_freecell *p, int a, int b )
{

	a = p->tableau[ a ].data;
	b = p->tableau[ b ].data;


	int rank;

	rank  = a % N_FREECELL_CARD_UNIT;
	rank -= b % N_FREECELL_CARD_UNIT;

	if ( rank == 1 )
	{
		return n_posix_true;
	}


	return n_posix_false;
}

int
n_freecell_rule_freespace( n_freecell *p )
{

	int freespace = 0;

	int x = 0;
	n_posix_loop
	{

		if ( p->tableau[ x ].data == N_FREECELL_NOTHING ) { freespace++; }

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	// [x] : difficult to determine

	int freespace_tableau = 0;

	x = 0;
	n_posix_loop
	{break;

		if ( p->tableau[ N_FREECELL_SUIT_MAX + x ].data == N_FREECELL_NOTHING ) { freespace_tableau++; }

		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return freespace;
}

n_posix_bool
n_freecell_rule_is_movable( n_freecell *p, int index )
{
//return n_posix_false;
//return n_posix_true;

	// Free cell

	if ( index < N_FREECELL_SUIT_MAX )
	{
		return ( p->tableau[ index ].data != N_FREECELL_NOTHING );
	}
 

	// Empty cell

	if ( p->tableau[ index ].data == N_FREECELL_NOTHING ) { return n_posix_false; }


	// Sequence Checker

	n_posix_bool ret = n_posix_false;

	int sequence = 0;

	int i = 0;
	n_posix_loop
	{

		int f = index + n_freecell_index_upper( i + 0 );
 		int t = index + n_freecell_index_upper( i + 1 );


		// Single : top most of a pile

		if ( t >= N_FREECELL_PILE_ALL ) { return n_posix_true; }


		// Single : top of a stock

		if ( p->tableau[ t ].data == N_FREECELL_NOTHING ) { ret = n_posix_true; break; }


		// Multiple

		if (
			( n_freecell_rule_half_is_ok( p, f, t ) )
			&&
			( n_freecell_rule_rank_is_ok( p, f, t ) )
		)
		{
			sequence++;
		} else {
			break;
		}


		i++;
		if ( f >= N_FREECELL_PILE_ALL ) { break; }
	}


	if ( ( ret )&&( sequence > p->freespace ) ) { ret = n_posix_false; }


	return ret;
}

n_posix_bool
n_freecell_rule_is_puttable( n_freecell *p, int index )
{
//return n_posix_true;

	// [Mechanism]
	//
	//	"index" : .data could have N_FREECELL_NOTHING


	n_posix_loop
	{

		// Cascading : Top to Bottom

		if ( p->tableau[ index ].data != N_FREECELL_NOTHING ) { break; }

		// Bottom-most

		index -= n_freecell_index_upper( 1 );
		if ( index < N_FREECELL_SUIT_MAX ) { return n_posix_true; }
	}


	return (
		( n_freecell_rule_rank_is_ok( p, index, p->drag_index ) )
		&&
		( n_freecell_rule_half_is_ok( p, index, p->drag_index ) )
	);
}

n_posix_bool
n_freecell_rule_stock_is_puttable( n_freecell *p, int f, int t )
{

	n_posix_bool ret = n_posix_false;

	int a = p->stock  [ t ].data;
	int b = p->tableau[ f ].data;
	int c = ( t + 0 ) * N_FREECELL_CARD_UNIT;
	int d = ( t + 1 ) * N_FREECELL_CARD_UNIT;
	int n = N_FREECELL_NOTHING;
//n_game_hwndprintf_literal( " Stock : %d %d %d ", a, b, c );

	if (
		( ( a == n )&&( c == b ) )
		||
		( ( a >= c )&&( ( a + 1 ) < d )&&( ( a + 1 ) == b ) )
	)
	{
		ret = n_posix_true;
	}


	return ret;
}

void
n_freecell_rule_stock( n_freecell *p, int index, int xxx, n_posix_bool *restore )
{

	if ( n_freecell_rule_stock_is_puttable( p, index, xxx ) )
	{

		p->stock  [   xxx ].data  = p->tableau[ index ].data;
		p->tableau[ index ].data  = N_FREECELL_NOTHING;

		p->stock  [   xxx ].chara = p->tableau[ index ].chara;
		p->tableau[ index ].chara = NULL;

		if ( p->tableau[ index ].dnd_onoff )
		{

			if ( n_game_chara_dnd_refcount >= 1 ) { n_game_chara_dnd_refcount--; }

			p->tableau[ index ].dnd_onoff = n_posix_false;
			p->tableau[ index ].dnd_ox    = 0;
			p->tableau[ index ].dnd_oy    = 0;

		}

		n_freecell_chara_erase( p, &p->tableau[ index ] );

		p->restore_count = 0;


		p->drag_index = N_FREECELL_NOTHING;

		n_freecell_sound_play( p, N_FREECELL_SOUND_CLICK );

		n_freecell_reposition( p );
		n_freecell_redraw( p );
		p->refresh = TRUE;

	} else {

		if ( restore != NULL ) { (*restore) = n_posix_true; }

	}


	return;
}

int
n_freecell_rule_number( n_freecell *p, int data )
{

	if ( data == -1 ) { return 0; }


	int h = N_FREECELL_SUIT_HEARTS   * N_FREECELL_CARD_UNIT;
	int d = N_FREECELL_SUIT_DIAMONDS * N_FREECELL_CARD_UNIT;
	int s = N_FREECELL_SUIT_SPADES   * N_FREECELL_CARD_UNIT;
	int c = N_FREECELL_SUIT_CLUBS    * N_FREECELL_CARD_UNIT;
	int m = N_FREECELL_SUIT_MAX      * N_FREECELL_CARD_UNIT;

	if ( ( data >= h )&&( data < d ) )
	{
		data -= h;
	} else
	if ( ( data >= d )&&( data < s ) )
	{
		data -= d;
	} else
	if ( ( data >= s )&&( data < c ) )
	{
		data -= s;
	} else
	if ( ( data >= c )&&( data < m ) )
	{
		data -= c;
	}


	return data;
}

int
n_freecell_rule_stock_minimum( n_freecell *p )
{

	// [!] : maximum based approach is problematic : dead lock will happen

	int ret = N_FREECELL_CARD_UNIT - 1;

	int x = 0;
	n_posix_loop
	{//break;

		int data = p->stock[ x ].data;
		if ( data != N_FREECELL_NOTHING ) { data = n_freecell_rule_number( p, data ); }

		if ( ret > data ) { ret = data; }

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	return ret + 1;
}

n_posix_bool
n_freecell_rule_stock_minimum_is_puttable( n_freecell *p, int minimum, int index )
{
//n_game_hwndprintf_literal( " %d %d %d %d ", p->stock[ 0 ].data, p->stock[ 1 ].data, p->stock[ 2 ].data, p->stock[ 3 ].data );

	int data = n_freecell_rule_number( p, p->tableau[ index ].data );

	return ( minimum >= data );
}

void
n_freecell_rule_automove( n_freecell *p, int threshold, int target )
{

	int xxx = 0;
	n_posix_loop
	{//break;
//n_freecell_rule_stock( p, i, xxx, NULL );

		if (
			( n_freecell_rule_stock_minimum_is_puttable( p, threshold, target ) )
			&&
			( n_freecell_rule_stock_is_puttable( p, target, xxx ) )
		)
		{
//n_freecell_animation_go( p, target, xxx );
			p->animation_server[ xxx ] = target;
		}

		xxx++;
		if ( xxx >= N_FREECELL_SUIT_MAX ) { break; }
	}

	return;
}

n_posix_bool
n_freecell_restore( n_freecell *p, int index )
{

	if ( index != N_FREECELL_NOTHING )
	{

		if ( n_posix_false == n_freecell_rule_is_movable( p, index ) ) { return n_posix_false; }


		n_game_chara_dnd( &p->tableau[ index ], 0, VK_LBUTTON );
		if ( n_posix_false == p->tableau[ index ].dnd_onoff ) { return n_posix_false; }


		if ( p->drag_index == N_FREECELL_NOTHING )
		{
//n_game_title_literal( " Restore : ON " );


			n_freecell_sound_play( p, N_FREECELL_SOUND_CLICK );


			p->drag_index = index;
//n_game_hwndprintf_literal( " %d ", p->drag_index );

			if ( p->drag_index < N_FREECELL_SUIT_MAX )
			{

				p->restore[ 0 ]  = p->tableau[ p->drag_index ];
				p->restore_count = 1;

			} else {

				int y = 0;
				n_posix_loop
				{//break;

					int upper = p->drag_index + n_freecell_index_upper( y );
					if ( upper >= N_FREECELL_PILE_ALL ) { break; }
					if ( p->tableau[ upper ].data == N_FREECELL_NOTHING ) { break; }

					p->restore[ y ] = p->tableau[ upper ];

					y++;
					if ( y >= N_FREECELL_PILE_SY ) { break; }
				}

				p->restore_count = y;

			}
//n_game_hwndprintf_literal( " %d ", p->restore_count );

			n_freecell_shadow( p );

		} else {

			// Multiple Dragging

			if ( p->restore_count >= 2 )
			{
				int i = 1;
				n_posix_loop
				{

					int upper = p->drag_index + n_freecell_index_upper( i );

					p->tableau[ upper ].x = p->tableau[ p->drag_index ].x;
					p->tableau[ upper ].y = p->tableau[ p->drag_index ].y + ( p->cardgen.osy * i );


					i++;
					if ( i >= p->restore_count ) { break; }
				}
			}


			// [!] : change halo color when puttable

//n_win_debug_count( game.hwnd );

			p->color_halo_current = p->cardgen.color_halo;

			n_type_gfx ox = p->cardgen.card_sx / 2;
			n_type_gfx oy = p->cardgen.card_sy / 2;

//static int i = 0;
//n_game_hwndprintf_literal( " %d : %d %d ", i, p->tableau[ p->drag_index ].x, p->tableau[ p->drag_index ].y );
//i++;

			int xxx = 0;
			n_posix_loop
			{//break;

				n_game_chara *f = &p->tableau[ p->drag_index ];
				n_game_chara *t = &p->stock[ xxx ];

//n_game_hwndprintf_literal( " %d %d %d ", f->x, t->x, ( t->x + t->sx ) );

				if (
					( p->restore_count == 1 )
					&&
					( n_game_chara_is_hit_offset( f, t, ox,oy, 0,0 ) )
					&&
					( n_freecell_rule_stock_is_puttable( p, p->drag_index, xxx ) )
				)
				{
//n_posix_debug_literal( " Stock : %d ", xxx );

					p->color_halo_current = p->color_halo_focus;

				}
//break;
				xxx++;
				if ( xxx >= N_FREECELL_SUIT_MAX ) { break; }
			}

			int xx = 0;
			n_posix_loop
			{

				n_game_chara *f = &p->tableau[ p->drag_index ];
				n_game_chara *t = &p->tableau[ xx ];

				if (
					( p->restore_count == 1 )
					&&
					( p->tableau[ xx ].data == N_FREECELL_NOTHING )
					&&
					( n_game_chara_is_hit_offset( f, t, ox,oy, 0,0 ) )
				)
				{

					p->color_halo_current = p->color_halo_focus;

					break;
				}

				xx++;
				if ( xx >= N_FREECELL_SUIT_MAX ) { break; }
			}


			int x = 0;
			int y = 0;
			n_posix_loop
			{

				int target = n_freecell_pos2index( x,y );

				if (
					( p->tableau[ target ].data == N_FREECELL_NOTHING )
					&&
					( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->tableau[ target ], ox,oy, 0,0 ) )
					&&
					( n_freecell_rule_is_puttable( p, target ) )
				)
				{

					p->color_halo_current = p->color_halo_focus;

					break;
				}

				x++;
				if ( x >= N_FREECELL_PILE_SX )
				{

					x = 0;

					y++;
					if ( y >= N_FREECELL_PILE_SY ) { break; }
				}
			}

		}


		// [!] : off for halo effect

		//if ( n_game_chara_is_moved( &p->tableau[ p->drag_index ] ) )
		{
			p->refresh = TRUE;
		}

	} else {

		if ( p->drag_index == N_FREECELL_NOTHING ) { return n_posix_false; }


		p->color_halo_current = p->cardgen.color_halo;


		n_posix_bool moved   = n_posix_false;
		n_posix_bool restore = n_posix_false;


		n_type_gfx ox = p->cardgen.card_sx / 2;
		n_type_gfx oy = p->cardgen.card_sy / 2;


		int xxx = 0;
		n_posix_loop
		{

			if (
				( p->restore_count == 1 )
				&&
				( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->stock[ xxx ], ox,oy, 0,0 ) )
			)
			{
//n_posix_debug_literal( " Stock : %d ", xxx );

				n_freecell_rule_stock( p, p->drag_index, xxx, &restore );

			}

			xxx++;
			if ( xxx >= N_FREECELL_SUIT_MAX ) { break; }
		}


		int xx = 0;
		n_posix_loop
		{
	
			if (
				( p->restore_count == 1 )
				&&
				( p->tableau[ xx ].data == N_FREECELL_NOTHING )
				&&
				( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->tableau[ xx ], ox,oy, 0,0 ) )
			)
			{
//n_game_title_literal( "Collision" );
				moved = n_posix_true;

				break;
			}

			xx++;
			if ( xx >= N_FREECELL_SUIT_MAX ) { break; }
		}


		int x = 0;
		int y = 0;
		n_posix_loop
		{

			if ( moved ) { break; }


			int target = n_freecell_pos2index( x,y );

			if (
				( p->tableau[ target ].data == N_FREECELL_NOTHING )
				&&
				( n_game_chara_is_hit_offset( &p->tableau[ p->drag_index ], &p->tableau[ target ], ox,oy, 0,0 ) )
				&&
				( n_freecell_rule_is_puttable( p, target ) )
			)
			{
//n_game_title_literal( " Collision " );
				moved = n_posix_true;

				break;
			}

			x++;
			if ( x >= N_FREECELL_PILE_SX )
			{

				x = 0;

				y++;
				if ( y >= N_FREECELL_PILE_SY ) { break; }
			}
		}


		if ( ( moved == n_posix_false )||( restore ) )
		{

			if ( p->drag_index < N_FREECELL_SUIT_MAX )
			{

				n_freecell_chara_erase( p, &p->tableau[ p->drag_index ] );

				if ( p->restore_count == 1 )
				{
					p->tableau[ p->drag_index ].data  = p->restore[ 0 ].data;
					p->tableau[ p->drag_index ].chara = p->restore[ 0 ].chara;

					n_game_chara_pos( &p->tableau[ p->drag_index ], p->cardgen.card_sx * p->drag_index, 0 );
					n_game_chara_prv( &p->tableau[ p->drag_index ] );
				}

			} else {

				int i = 0;
				n_posix_loop
				{

					int upper = p->drag_index + n_freecell_index_upper( i );

					n_freecell_chara_erase( p, &p->tableau[ upper ] );

					p->tableau[ upper ] = p->restore[ i ];


					i++;
					if ( i >= p->restore_count ) { break; }
				}

			}

		} else
		if ( xx != N_FREECELL_SUIT_MAX )
		{

			// Move

			int f = p->drag_index;
			int t = xx;


			// [!] : erase the last dragged position

			n_freecell_chara_erase( p, &p->tableau[ f ] );


			// [!] : restore x,y,px,py

			n_game_chara_pos( &p->tableau[ f ], p->restore[ 0 ].x, p->restore[ 0 ].y );
			n_game_chara_prv( &p->tableau[ f ] );

			n_game_chara_pos( &p->tableau[ t ], p->cardgen.card_sx * t, 0 );
			n_game_chara_prv( &p->tableau[ t ] );


			p->tableau[ t ].data  = p->tableau[ f ].data;
			p->tableau[ f ].data  = N_FREECELL_NOTHING;

			p->tableau[ t ].chara = p->tableau[ f ].chara;
			p->tableau[ f ].chara = NULL;

		} else {

			// [!] : cascade to the bottom most

			n_posix_loop
			{

				int target = n_freecell_pos2index( x,y );

				if ( p->tableau[ target ].data != N_FREECELL_NOTHING ) { break; }

				y--;
				if ( y < 0 ) { break; }
			}
			y++;

			int i = 0;
			n_posix_loop
			{

				int f = n_freecell_index_upper( i ) + p->drag_index;
				int t = n_freecell_index_upper( i ) + n_freecell_pos2index( x,y );


				// [!] : erase the last dragged position

				n_freecell_chara_erase( p, &p->tableau[ f ] );


				// Move

				p->tableau[ t ].data  = p->tableau[ f ].data;
				p->tableau[ f ].data  = N_FREECELL_NOTHING;

				p->tableau[ t ].chara = p->tableau[ f ].chara;
				p->tableau[ f ].chara = NULL;


				i++;
				if ( i >= p->restore_count ) { break; }
			}

		}


		p->tableau[ p->drag_index ].dnd_onoff = n_posix_false;
		p->drag_index = N_FREECELL_NOTHING;


		n_freecell_sound_play( p, N_FREECELL_SOUND_CLICK );

		n_freecell_reposition( p );
		n_freecell_redraw( p );
		p->refresh = TRUE;

	}


	return n_posix_true;
}

void
n_freecell_shuffle( n_freecell *p )
{

	if ( p->debug_onoff ) { return; }

	int i = 0;
	n_posix_loop
	{//break;

		int r = n_random_range_hq( N_FREECELL_CARD_ALL );

		int swap        = p->shuffle[ i ];
		p->shuffle[ i ] = p->shuffle[ r ];
		p->shuffle[ r ] = swap;


		i++;
		if ( i >= N_FREECELL_CARD_ALL ) { break; }
	}


	return;
}

void
n_freecell_reset( n_freecell *p, n_posix_bool is_init )
{
//u32 tick = n_posix_tickcount();

	// Reset : once per session

	p->drag_index = N_FREECELL_NOTHING;


	p->is_done = n_posix_false;


	if ( is_init )
	{
		n_game_chara_bulk_zero( p->bottom,   N_FREECELL_PILE_SX  );
		n_game_chara_bulk_zero( p->tableau,  N_FREECELL_PILE_ALL );
		n_game_chara_bulk_zero( p->freecell, N_FREECELL_SUIT_MAX );
		n_game_chara_bulk_zero( p->stock,    N_FREECELL_SUIT_MAX );
	}


	int x,y;


	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg;

		n_game_chara_bmp( &p->freecell[ x ], &p->canvas, &p->bmp_freecell, bmp_bg, p->color_bg );
		n_game_chara_src( &p->freecell[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

		p->freecell[ x ].data = N_FREECELL_NOTHING;

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg;

		if ( is_init )
		{
			n_game_chara_bmp( &p->tableau[ x ], &p->canvas, NULL, bmp_bg, p->color_bg );
			n_game_chara_src( &p->tableau[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

			p->tableau[ x ].data = N_FREECELL_NOTHING;
		} else {
			n_game_chara_src( &p->tableau[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );
		}

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg;

		if ( is_init )
		{
			n_game_chara_bmp( &p->stock[ x ], &p->canvas, &p->bmp_stock[ x ], bmp_bg, p->color_bg );
			n_game_chara_src( &p->stock[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

			p->stock[ x ].data = N_FREECELL_NOTHING;
		} else {
			n_game_chara_src( &p->stock[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );
		}

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

	x = 0;
	n_posix_loop
	{

		p->animation_server[ x ] = N_FREECELL_NOTHING;

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	x = 0;
	n_posix_loop
	{

		n_bmp *bmp_bg = &p->bmp_bg;

		n_game_chara_bmp( &p->bottom[ x ], &p->canvas, &p->cardgen.bmp_foundation, bmp_bg, p->color_bg );
		n_game_chara_src( &p->bottom[ x ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );

		p->bottom[ x ].data = N_FREECELL_NOTHING;


		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	x = y = 0;
	int i = 0;
	n_posix_loop
	{

		int    target = n_freecell_pos2index( x,y );
		n_bmp *bmp_bg = &p->bmp_bg;

		if ( is_init )
		{
			n_game_chara_bmp( &p->tableau[ target ], &p->canvas, NULL, bmp_bg, p->color_bg );
			n_game_chara_src( &p->tableau[ target ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );


			if ( i < N_FREECELL_CARD_ALL )
			{
				p->tableau[ target ].chara = &p->cardgen.cards[ p->shuffle[ i ] ];
				p->tableau[ target ].data  = p->shuffle[ i ];
				i++;
			} else {
				p->tableau[ target ].chara = NULL;
				p->tableau[ target ].data  = N_FREECELL_NOTHING;
			}
		} else {
			n_game_chara_src( &p->tableau[ target ], 0,0, p->cardgen.card_sx,p->cardgen.card_sy, 0,0 );
		}

		x++;
		if ( x >= N_FREECELL_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}
	}


	n_freecell_shadow( p );


	p->color_halo_current = p->cardgen.color_halo;


//n_posix_debug_literal( " %d ", n_posix_tickcount() - tick );
	return;
}

void
n_freecell_redirect( n_freecell *p, n_bmp *bmp )
{

	int x,y;


	x = 0;
	n_posix_loop
	{

		p->freecell[ x ].main = bmp;

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

	x = 0;
	n_posix_loop
	{

		p->tableau[ x ].main = bmp;

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}

	x = 0;
	n_posix_loop
	{

		p->stock[ x ].main = bmp;

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	x = 0;
	n_posix_loop
	{

		p->bottom[ x ].main = bmp;


		x++;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	x = y = 0;
	n_posix_loop
	{

		int target = n_freecell_pos2index( x,y );

		p->tableau[ target ].main = bmp;

		x++;
		if ( x >= N_FREECELL_PILE_SX )
		{

			x = 0;

			y++;
			if ( y >= N_FREECELL_PILE_SY ) { break; }
		}
	}


	return;
}

void
n_freecell_input_doubleclick( n_freecell *p )
{

	if ( p->animation_onoff ) { return; }


	int i = N_FREECELL_TABLEAU - 1;
	n_posix_loop
	{

		n_game_chara *c = &p->tableau[ i ];

		if (
			( p->tableau[ i ].data != N_FREECELL_NOTHING )
			&&
			( n_mac_is_hovered_offset( p, c->x,c->y,c->sx,c->sy ) )
		)
		{
//NSLog( @" %d ", i );
			int xxx = 0;
			n_posix_loop
			{//break;
//n_freecell_rule_stock( p, i, xxx, NULL );

				if ( n_freecell_rule_stock_is_puttable( p, i, xxx ) )
				{
					n_freecell_animation_go( p, i, xxx );
				}

				xxx++;
				if ( xxx >= N_FREECELL_SUIT_MAX ) { break; }
			}

			break;
		}

		i--;
		if ( i < 0 ) { break; }
	}


	return;
}

void
n_freecell_input( n_freecell *p )
{

	if ( p->animation_onoff ) { return; }


	// DnD

	int dnd = 0;

	int i = N_FREECELL_TABLEAU - 1;
	n_posix_loop
	{

		p->freespace = n_freecell_rule_freespace( p );

		n_posix_bool break_needed = n_posix_false;
		if ( n_freecell_restore( p, i ) ) { break_needed = n_posix_true; }

		dnd += p->tableau[ i ].dnd_onoff;

		if ( break_needed ) { break; }

		i--;
		if ( i < 0 )
		{
			n_freecell_restore( p, N_FREECELL_NOTHING );
			break;
		}
	}

	if ( ( dnd == 0 )&&( n_game_chara_dnd_refcount != 0 ) ) { n_game_chara_dnd_refcount = 0; }


	return;
}

#define N_FREECELL_PILE_ERASE 0
#define N_FREECELL_PILE_DRAW  1

#define n_freecell_pile_erase( p, x,y ) n_freecell_pile( p, x,y, N_FREECELL_PILE_ERASE )
#define n_freecell_pile_draw(  p, x,y ) n_freecell_pile( p, x,y, N_FREECELL_PILE_DRAW  )

void
n_freecell_pile( n_freecell *p, int x, int y, int mode )
{

	// [!] : draw always for alpha blending

	if ( y == 0 )
	{

		if ( mode == N_FREECELL_PILE_ERASE )
		{
			n_game_chara_erase( &p->bottom[ x ] );
		} else {
			// [Needed] : alpha value of foundation needs this

			n_posix_bool p_multithread = n_bmp_is_multithread;
			n_bmp_is_multithread = n_posix_true;

			n_game_chara_draw ( &p->bottom[ x ] );
//n_bmp_box( &game.bmp, p->bottom[ x ].x,p->bottom[ x ].y, p->bottom[ x ].sx,10, n_game_randomcolor() );

			n_bmp_is_multithread = p_multithread;
		}

	}

#ifdef N_FREECELL_DEBUG_FOUNDATION

return;

#endif

	n_posix_loop
	{

		n_game_chara *c = &p->tableau[ n_freecell_pos2index( x, y + 0 ) ];

		if ( c->data == N_FREECELL_NOTHING ) { break; }


		// [!] : dragged cards are handled as overlay

		if ( p->drag_index != N_FREECELL_NOTHING )
		{
			if ( p->drag_index == n_freecell_pos2index( x,y ) ) { break; }
		}


		if ( mode == N_FREECELL_PILE_ERASE )
		{
			n_game_chara_erase( c );
		} else {
			n_game_chara_draw ( c );
//n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_game_randomcolor() );
		}


		y++;
		if ( y >= N_FREECELL_PILE_SY ) { break; }
	}


	return;
}

typedef struct {

	n_freecell *freecell;
	int         offset, cores;

} n_freecell_pile_draw_all_thread_struct;

#ifdef N_POSIX_PLATFORM_WINDOWS
DWORD WINAPI
#else  // #ifdef N_POSIX_PLATFORM_WINDOWS
u32
#endif // #ifdef N_POSIX_PLATFORM_WINDOWS
n_freecell_pile_draw_all_thread( LPVOID lpParameter )
{

	n_freecell_pile_draw_all_thread_struct *p = (void*) lpParameter;


	int x = p->offset;
	n_posix_loop
	{

		if ( p->freecell->redraw[ x ] )
		{
			p->freecell->redraw[ x ] = n_posix_false;
			n_freecell_pile_draw( p->freecell, x, 0 );
/*
n_game_chara *c = &p->freecell->tableau[ n_freecell_pos2index( x, 0 ) ];
if ( 0 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 0,200,255 ) ); }
if ( 1 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 255,0,200 ) ); }
if ( 2 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 0,  0,255 ) ); }
if ( 3 == ( x % p->cores ) ) { n_bmp_box( &game.bmp, c->x,c->y, c->sx,10, n_bmp_rgb( 255,0,  0 ) ); }
*/
		}

		x += p->cores;
		if ( x >= N_FREECELL_PILE_SX ) { break; }
	}


	return 0;
}

void
n_freecell_pile_draw_all( n_freecell *p )
{

	if ( 1 )
	{

		// [!] : for Mac

		u32 cores = N_FREECELL_PILE_SX;

		NSOperationQueue *q = p->queue;//[[NSOperationQueue alloc] init];

		int i = 0;
		n_posix_loop
		{

			n_freecell_pile_draw_all_thread_struct tmp = { p, i, cores };

			NSOperation *o = [NSBlockOperation blockOperationWithBlock:^{
				n_freecell_pile_draw_all_thread( (void*) &tmp );
			}];

			[q addOperation:o];

			i++;
			if ( i >= cores ) { break; }
		}

		[q waitUntilAllOperationsAreFinished];

	} else
	if ( n_thread_onoff() )
	{

		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		u32 cores = n_posix_min( n_thread_core_count, N_FREECELL_PILE_SX );
		//if ( cores > 1 ) { cores--; }
//NSLog( @"%d", cores );


		n_thread                               *h = n_memory_new( cores * sizeof( n_thread                               ) );
		n_freecell_pile_draw_all_thread_struct *f = n_memory_new( cores * sizeof( n_freecell_pile_draw_all_thread_struct ) );

		u32 i = 0;
		n_posix_loop
		{

			n_freecell_pile_draw_all_thread_struct tmp = { p, i, cores };
			n_memory_copy( &tmp, &f[ i ], sizeof( n_freecell_pile_draw_all_thread_struct ) );

			h[ i ] = n_thread_init( n_freecell_pile_draw_all_thread, &f[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( f );


		n_bmp_is_multithread = p_multithread;

	} else {

		int x = 0;
		n_posix_loop
		{

			if ( p->redraw[ x ] )
			{
//LARGE_INTEGER li_f; QueryPerformanceCounter( &li_f );

				p->redraw[ x ] = n_posix_false;
				n_freecell_pile_draw( p, x, 0 );

//LARGE_INTEGER li_t; QueryPerformanceCounter( &li_t );
//if ( x == 0 )  { n_game_hwndprintf_literal( " %d ", li_t.QuadPart - li_f.QuadPart ); }
			}


			x++;
			if ( x >= N_FREECELL_PILE_SX ) { break; }
		}

	}


	return;
}

void
n_freecell_newgame( n_freecell *p )
{

	n_freecell_shuffle( p );
	n_freecell_reset( p, n_posix_true );
	n_freecell_reposition( p );
	n_freecell_redraw( p );

	n_bmp_flush_fastcopy( &p->bmp_bg, &p->canvas );


	return;
}

void
n_freecell_replay( n_freecell *p )
{

	n_freecell_reset( p, n_posix_true );
	n_freecell_reposition( p );
	n_freecell_redraw( p );

	n_bmp_flush_fastcopy( &p->bmp_bg, &p->canvas );


	return;
}

void
n_freecell_flush_background_cached( n_freecell *p )
{

	{

		n_bmp_flush( &p->bmp_bg, p->color_gradient_upper );

		n_type_gfx sx = p->sx;
		n_type_gfx sy = p->sy / 3;

		n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );
		u32 color = n_bmp_alpha_replace_pixel( p->color_gradient_upper, 0 );
		n_bmp_flush_gradient( &b, color, p->color_gradient_lower, N_BMP_GRADIENT_VERTICAL );

		n_bmp_transcopy( &b, &p->bmp_bg, 0,0,sx,sy, 0, ( sy * 2 ) + 2 );
		n_bmp_free_fast( &b );

	}


	return;
}

void
n_freecell_flush_background( n_freecell *p )
{

	{

		n_bmp_flush( &p->canvas, p->color_gradient_upper );

		n_type_gfx sx = p->sx;
		n_type_gfx sy = p->sy / 3;

		n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );
		u32 color = n_bmp_alpha_replace_pixel( p->color_gradient_upper, 0 );
		n_bmp_flush_gradient( &b, color, p->color_gradient_lower, N_BMP_GRADIENT_VERTICAL );

		n_bmp_transcopy( &b, &p->canvas, 0,0,sx,sy, 0, ( sy * 2 ) + 2 );
		n_bmp_free_fast( &b );

	}

	n_bmp_free( &p->bmp_bg );
	n_bmp_carboncopy( &p->canvas, &p->bmp_bg );


	return;
}

void
n_freecell_accentcolor_changed( n_freecell *p )
{

	{

		n_bmp_flush( &p->canvas, p->color_gradient_upper );

		n_type_gfx sx = p->sx;
		n_type_gfx sy = p->sy / 3;

		n_bmp b; n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );
		u32 color = n_bmp_alpha_replace_pixel( p->color_gradient_upper, 0 );
		n_bmp_flush_gradient( &b, color, p->color_gradient_lower, N_BMP_GRADIENT_VERTICAL );

		n_bmp_transcopy( &b, &p->canvas, 0,0,sx,sy, 0, ( sy * 2 ) + 2 );
		n_bmp_free_fast( &b );

	}

	n_bmp_free( &p->bmp_bg );
	n_bmp_carboncopy( &p->canvas, &p->bmp_bg );


	return;
}

void
n_freecell_style_change_color( n_freecell *p )
{

	u32 accent = n_bmp_color_mac( n_mac_nscolor2argb( [NSColor controlAccentColor] ) );

	if ( n_cardgenerator_darkmode_is_on() )
	{
		p->cardgen.color_margin     = n_bmp_black_invisible;
		p->cardgen.color_halo       = n_bmp_rgb_mac( 11,11,11 );
		p->        color_halo_focus = accent;

		p->color_gradient_lower = accent;
		p->color_gradient_upper = n_bmp_rgb_mac( 33,33,33 );
	} else {
		p->cardgen.color_margin     = n_bmp_white_invisible;
		p->cardgen.color_halo       = accent;
		p->        color_halo_focus = n_bmp_rgb_mac( 255,255,0 );

		p->color_gradient_upper = accent;
		p->color_gradient_lower = n_bmp_white;
	}

	p->color_halo_current = p->cardgen.color_halo;


	return;
}

void
n_freecell_style_change( n_freecell *p )
{

	p->is_first = n_posix_true;

	n_freecell_style_change_color( p );

	n_cardgenerator_exit( &p->cardgen );
	n_cardgenerator_init( &p->cardgen, 10 );


	return;
}

void
n_freecell_automove( n_freecell *p )
{

	if ( p->is_init      == n_posix_false ) { return; }
	if ( p->splash_onoff == n_posix_false ) { return; }

	if ( FALSE != p->refresh ) { return; }

	if ( p->animation_onoff ) { return; }


	int threshold = n_freecell_rule_stock_minimum( p );
//n_game_hwndprintf_literal( " %d ", threshold );


	// [!] : Freecell Area

	{

		int x = 0;
		n_posix_loop
		{

			n_game_chara *c = &p->tableau[ x ];
			if ( c->data != N_FREECELL_NOTHING )
			{
				n_freecell_rule_automove( p, threshold, x );
			}

			x++;
			if ( x >= N_FREECELL_SUIT_MAX ) { break; }
		}

	}


	// [!] : Tableau Area

	int x = 0;
	int y = N_FREECELL_PILE_SY - 1;
	n_posix_loop
	{

		int target = n_freecell_pos2index( x, y );

		n_game_chara *c = &p->tableau[ target ];
		if ( c->data != N_FREECELL_NOTHING )
		{
			n_freecell_rule_automove( p, threshold, target );
			y = 0;
		}

		y--;
		if ( y < 0 )
		{

			y = N_FREECELL_PILE_SY - 1;

			x++;
			if ( x >= N_FREECELL_PILE_SX ) { break; }
		}
	}


	return;
}

void
n_freecell_automove_engine( n_freecell *p )
{

//p->debug_automove_count = 0;

	int done = 0;

	int x = 0;
	n_posix_loop
	{

		if (
			( p->animation_onoff == n_posix_false )
			&&
			( p->animation_server[ x ] != N_FREECELL_NOTHING )
		)
		{
			done++;

			n_freecell_animation_go( p, p->animation_server[ x ], x );

			p->animation_server[ x ] = N_FREECELL_NOTHING;

			break;
		}

		x++;
		if ( x >= N_FREECELL_SUIT_MAX ) { break; }
	}


	if ( done == 0 )
	{
//n_posix_debug_literal( "" );
		n_freecell_automove( p );
	}


	return;
}

void
n_freecell_cardgenerator( n_freecell *p )
{

	// [!] : Freecell Area

	const u32 freecell = n_bmp_argb( 50, 255,255,255 );

	n_cardgenerator_base( &p->cardgen, &p->bmp_freecell, freecell, 0 );

	u32 color_frame  = p->cardgen.color_frame ; p->cardgen.color_frame  = n_bmp_white_invisible;
	u32 color_margin = p->cardgen.color_margin; p->cardgen.color_margin = n_bmp_black_invisible;

	n_cardgenerator_resampler( &p->cardgen, &p->bmp_freecell, n_bmp_black_invisible );

	p->cardgen.color_frame  = color_frame;
	p->cardgen.color_margin = color_margin;


	// [!] : Placeholder

	n_bmp_carboncopy( &p->cardgen.cards[ N_CARDGENERATOR_CARD_UNIT * 0 ], &p->bmp_stock[ 0 ] );
	n_bmp_carboncopy( &p->cardgen.cards[ N_CARDGENERATOR_CARD_UNIT * 1 ], &p->bmp_stock[ 1 ] );
	n_bmp_carboncopy( &p->cardgen.cards[ N_CARDGENERATOR_CARD_UNIT * 2 ], &p->bmp_stock[ 2 ] );
	n_bmp_carboncopy( &p->cardgen.cards[ N_CARDGENERATOR_CARD_UNIT * 3 ], &p->bmp_stock[ 3 ] );

	n_cardgenerator_gray( &p->bmp_stock[ 0 ] );
	n_cardgenerator_gray( &p->bmp_stock[ 1 ] );
	n_cardgenerator_gray( &p->bmp_stock[ 2 ] );
	n_cardgenerator_gray( &p->bmp_stock[ 3 ] );


	// [!] : shadow

	int i = 0;
	n_posix_loop
	{

		n_bmp_free( &p->shadow_bmp_cache[ i ] );

		i++;
		if ( i >= N_FREECELL_SHADOW_COUNT ) { break; }
	}


	return;
}




#define n_freecell_zero( p ) n_memory_zero( p, sizeof( n_freecell ) )

void
n_freecell_init( n_freecell *p )
{

	// Global #1

	n_bmp_safemode_base = n_bmp_safemode = n_posix_false;

	n_random_shuffle();

	n_freecell_style_change( p );

	p->shadow_global_onoff = n_posix_true;

	p->queue = [[NSOperationQueue alloc] init];


	// System

	p->sx       = p->cardgen.csx;
	p->sy       = p->cardgen.csy;
	p->color_bg = n_bmp_white;

	n_bmp_new_fast( &p->canvas, p->sx, p->sy );


	// Resource

	//n_freecell_watcher( p );


	n_freecell_snd_click   = n_mac_sound_init( @"click", @"wav" );
	n_freecell_snd_fanfare = n_mac_sound_init( @"get"  , @"wav" );


	// New Game

	int i = 0;
	n_posix_loop
	{

		p->shuffle[ i ] = N_FREECELL_CARD_ALL - 1 - i;

		i++;
		if ( i >= N_FREECELL_CARD_ALL ) { break; }
	}

	n_freecell_shuffle( p );


	// Debug : Automove

	    i = 0;
	int j = 0;
	while( p->debug_onoff )
	{//break;

		p->shuffle[ i + 3 ] = ( ( 1 + N_FREECELL_SUIT_HEARTS   ) * N_FREECELL_CARD_UNIT ) - 1 - j;
		p->shuffle[ i + 2 ] = ( ( 1 + N_FREECELL_SUIT_DIAMONDS ) * N_FREECELL_CARD_UNIT ) - 1 - j;
		p->shuffle[ i + 1 ] = ( ( 1 + N_FREECELL_SUIT_SPADES   ) * N_FREECELL_CARD_UNIT ) - 1 - j;
		p->shuffle[ i + 0 ] = ( ( 1 + N_FREECELL_SUIT_CLUBS    ) * N_FREECELL_CARD_UNIT ) - 1 - j;

		j++;

		i += 4;
		if ( i >= N_FREECELL_CARD_ALL ) { break; }
	}

	if ( p->debug_onoff ) { p->restore_count = 4; }


	return;
}

void
n_freecell_loop( n_freecell *p )
{

	n_cardgenerator_loop( &p->cardgen );
	if ( p->is_first )
	{

		p->is_first = n_posix_false;


		n_bmp_flip_onoff = n_posix_false;

		n_freecell_cardgenerator( p );

		n_bmp_flip_onoff = n_posix_true;


		p->splash_onoff = p->is_init = n_posix_true;

		n_freecell_flush_background( p );

		n_freecell_reset( p, n_posix_true );
		n_freecell_reposition( p );
		n_freecell_redraw( p );


		n_bmp_carboncopy( &p->bmp_bg, &p->transition_bmp_old );

		n_bmp_carboncopy( &p->bmp_bg, &p->transition_bmp_new );
		n_freecell_redirect( p, &p->transition_bmp_new );

		p->refresh = TRUE;
		n_freecell_loop( p );

		n_freecell_redirect( p, &p->canvas );


		p->transition_onoff = n_posix_true;

//n_bmp_save_literal( &p->transition_bmp_old, "old.bmp" );
//n_bmp_save_literal( &p->transition_bmp_new, "new.bmp" );

	}


	if ( p->transition_onoff )
	{
		n_posix_bool ret = n_game_transition
		(
			&p->canvas,
			&p->transition_bmp_old,
			&p->transition_bmp_new,
			N_FREECELL_FADE_MSEC,
			&p->transition_percent,
			N_GAME_TRANSITION_FADE
		);
		if ( ret )
		{
			p->transition_onoff = n_posix_false;

			n_bmp_free( &p->transition_bmp_old );
			n_bmp_free( &p->transition_bmp_new );
		}

		p->refresh = TRUE;
		return;
	}


	// Input
//n_game_hwndprintf_literal( " %d ", p->animation_onoff );

	if ( p->doubleclick )
	{
		n_freecell_input_doubleclick( p );
	} else {
		n_freecell_input( p );
	}


	// Automove

	n_freecell_automove_engine( p );


//n_game_hwndprintf_literal( " %d %d %d %d ", p->stock[ 0 ].data, p->stock[ 1 ].data, p->stock[ 2 ].data, p->stock[ 3 ].data );

	if ( p->is_done == n_posix_false )
	{
		if (
			( p->stock[ 0 ].data == 12 )
			&&
			( p->stock[ 1 ].data == 25 )
			&&
			( p->stock[ 2 ].data == 38 )
			&&
			( p->stock[ 3 ].data == 51 )
		)
		{
			p->is_done = n_posix_true;
			n_freecell_sound_play( p, N_FREECELL_SOUND_FANFARE );
		}
	}


	// Auto Animation

	if ( p->animation_onoff )
	{
//static int i = 0;
//n_game_hwndprintf_literal( " %d : %f %f ", i, p->animation_step_x, p->animation_step_y );
//i++;

		static u32 timer = 0;
		if ( n_game_timer( &timer, N_FREECELL_ANIMATION_INTERVAL ) )
		{

			n_type_gfx ox = p->cardgen.card_sx / 2;
			n_type_gfx oy = p->cardgen.card_sy / 2;

			if ( n_game_chara_is_hit_offset( &p->tableau[ p->animation_index_f ], &p->stock[ p->animation_index_t ], ox,oy, 0,0 ) )
			{
				p->animation_onoff = n_posix_false;
				p->drag_index      = N_FREECELL_NOTHING;
				n_freecell_rule_stock( p, p->animation_index_f, p->animation_index_t, NULL );

				n_freecell_automove_engine( p );
			} else {
				n_game_chara *c = &p->tableau[ p->animation_index_f ];

				p->animation_base_x += p->animation_step_x;
				p->animation_base_y += p->animation_step_y;

				c->x = (n_type_gfx) p->animation_base_x;
				c->y = (n_type_gfx) p->animation_base_y;
			}

			//n_freecell_redraw( p );
			p->refresh = TRUE;

		}

	}




	// Watcher
/*
	{

		n_type_gfx cursor_x = 0; //n_win_cursor_position_relative( game.hwnd, &cursor_x, NULL );

		n_posix_bool redraw = n_posix_false;

		if ( cursor_x < ( p->sx / 2 ) )
		{
			if ( p->watcher != N_FREECELL_WATCHER_L )
			{
				p->watcher = N_FREECELL_WATCHER_L;
				redraw = n_posix_true;
			}
		} else {
			if ( p->watcher != N_FREECELL_WATCHER_R )
			{
				p->watcher = N_FREECELL_WATCHER_R;
				redraw = n_posix_true;
			}
		}

		if ( redraw ) { p->refresh = TRUE; }

	}
*/

	if ( p->refresh )
	{

//n_game_hwndprintf_literal( "%d", p->restore_count );


		// Erase

		// [!] : Safe Mode

		//n_freecell_redraw( p );
		//n_bmp_flush_fastcopy( &p->bmp_bg, &p->canvas );


		// [!] : Fast Mode

		{

			if ( p->drag_index != N_FREECELL_NOTHING )
			{

				n_freecell_redraw_detect( p );

				int i = 0;
				n_posix_loop
				{

					int upper = p->drag_index + n_freecell_index_upper( i );

					n_game_chara *c = &p->tableau[ upper ];

					n_freecell_chara_erase( p, c );

					i++;
					if ( i >= p->restore_count ) { break; }
				}

			}

		}


		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_erase( &p->freecell[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}


		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_erase( &p->stock[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}


		n_freecell_shadow_erase( p );

		{

			n_posix_bool prv = n_bmp_is_multithread;
			n_bmp_is_multithread = n_posix_true;

			int x = 0;
			n_posix_loop
			{

				NSOperation *o = [NSBlockOperation blockOperationWithBlock:^{

				if ( p->redraw[ x ] ) { n_freecell_pile_erase( p, x, 0 ); }

				}];
				[p->queue addOperation:o];


				x++;
				if ( x >= N_FREECELL_PILE_SX ) { break; }
			}

			[p->queue waitUntilAllOperationsAreFinished];

			n_bmp_is_multithread = prv;

		}


		// Draw
/*
		{

			n_type_gfx sx = N_BMP_SX( &p->bmp_neko_l );
			n_type_gfx sy = N_BMP_SX( &p->bmp_neko_l );
			n_type_gfx tx = (              p->sx / 2 ) - ( sx / 2 );
			n_type_gfx ty = ( p->cardgen.card_sy / 2 ) - ( sy / 2 );

			if ( p->watcher == N_FREECELL_WATCHER_L )
			{
				n_bmp_transcopy( &p->bmp_neko_l, &p->canvas, 0,0,sx,sy, tx,ty );
			} else {
				n_bmp_transcopy( &p->bmp_neko_r, &p->canvas, 0,0,sx,sy, tx,ty );
			}

		}
*/
		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_draw( &p->freecell[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}

		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_draw( &p->stock[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}


		{

			int x = 0;
			n_posix_loop
			{

				n_game_chara_draw( &p->tableau[ x ] );

				x++;
				if ( x >= N_FREECELL_SUIT_MAX ) { break; }
			}

		}


		n_freecell_pile_draw_all( p );


		if ( p->drag_index != N_FREECELL_NOTHING )
		{

			n_freecell_shadow_draw( p );

			int i = 0;
			n_posix_loop
			{//break;

				int upper = p->drag_index + n_freecell_index_upper( i );

				n_game_chara *c = &p->tableau[ upper ];

				n_freecell_chara_draw( p, c );
//n_bmp_box( &game.bmp, c->x, c->y, c->sx, c->sy, n_bmp_rgb( 0,200,255 ) );

				i++;
				if ( i >= p->restore_count ) { break; }
			}

		}

	}


	return;
}

void
n_freecell_exit( n_freecell *p )
{

	n_cardgenerator_exit( &p->cardgen );


	int i = 0;
	n_posix_loop
	{

		n_bmp_free( &p->bmp_stock[ i ] );

		i++;
		if ( i >= N_FREECELL_SUIT_MAX ) { break; }
	}


	n_bmp_free_fast( &p->bmp_bg       );
	n_bmp_free_fast( &p->bmp_freecell );
	n_bmp_free_fast( &p->bmp_neko_l   );
	n_bmp_free_fast( &p->bmp_neko_r   );

	i = 0;
	n_posix_loop
	{

		n_bmp_free_fast( &p->shadow_bmp_cache[ i ] );

		i++;
		if ( i >= N_FREECELL_SHADOW_COUNT ) { break; }
	}


	n_freecell_zero( p );


	//n_memory_debug_refcount();


	return;
}
