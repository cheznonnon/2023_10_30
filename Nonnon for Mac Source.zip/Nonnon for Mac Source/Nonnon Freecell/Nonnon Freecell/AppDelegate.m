//
//  AppDelegate.m
//  Nonnon Freecell
//
//  Created by のんのん on 2022/07/20.
//

#import "AppDelegate.h"


#include "n_game.c"




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonGame *n_game;

@end




@implementation AppDelegate


- (void)awakeFromNib
{
//NSLog( @"awakeFromNib" );

	n_mac_image_window = _window;

	[_n_game n_mac_game_init];

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowDidResize: )
		     name: NSWindowDidResizeNotification
		   object: nil
	];

	// [!] : accent color
	[[NSDistributedNotificationCenter defaultCenter]
		addObserver: self
		   selector: @selector( accentColorChanged: )
		       name: @"AppleColorPreferencesChangedNotification"
		     object: nil
	];

	// [!] : dark mode
	[[NSDistributedNotificationCenter defaultCenter]
		addObserver: self
		   selector: @selector( darkModeChanged: )
		       name: @"AppleInterfaceThemeChangedNotification"
		     object: nil
	];

	[_n_game n_mac_game_canvas_resize:_window width:-1 height:-1];

}




- (void) accentColorChanged:(NSNotification *)notification
{
//NSLog( @"accentColorChanged" );

	[_n_game n_accentColorChanged];

}

- (void) darkModeChanged:(NSNotification *)notification
{
//NSLog( @"darkModeChanged" );

	[_n_game n_darkModeChanged];

}




- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}


- (void) windowDidResize:(NSNotification *)notification
{
//NSLog( @"resized" );

	[_n_game n_on_resize:_window];

}


- (void)applicationWillFinishLaunching:(NSNotification *)aNotification {
//NSLog( @"applicationWillFinishLaunching" );
}



- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (IBAction)n_freecell_newgame:(id)sender {

	[_n_game n_newgame];

}

- (IBAction)n_freecell_replay:(id)sender {

	[_n_game n_replay];

}
- (IBAction)n_freecell_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"freecell" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}


@end
