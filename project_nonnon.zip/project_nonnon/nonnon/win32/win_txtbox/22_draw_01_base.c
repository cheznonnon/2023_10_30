// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_win_txtbox_draw_box( n_win_txtbox *p, HDC hdc, RECT *rect, COLORREF color )
{
//return;

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{

		n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

		if ( color == p->color_back_selected )
		{
			// [!] : for contour
			 x -= p->scale;
			sx += p->scale * 2;
		}

		int a = 222; if ( color == 0 ) { a = 0; }
		int r = GetRValue( color );
		int g = GetGValue( color );
		int b = GetBValue( color );

		n_bmp_box( &p->bmp, x,y,sx,sy, n_bmp_argb( a,r,g,b ) );

	} else {

		n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

		u32 argb = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color ) );

		n_bmp_box( &p->bmp, x,y,sx,sy, argb );

	}


	return;
}

// internal
void
n_win_txtbox_draw_box_invert( n_win_txtbox *p, n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_type_real blend )
{
//return;

	// [!] : InvertRect() only supports black and white


	n_type_gfx xx = 0;
	n_type_gfx yy = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get( bmp, x+xx,y+yy, &color );

		int a =       n_bmp_a( color );
		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		color = n_bmp_blend_pixel( color, n_bmp_argb( a,r,g,b ), blend );

		n_bmp_ptr_set( bmp, x+xx,y+yy, color );

		xx++;
		if ( xx >= sx )
		{

			xx = 0;

			yy++;
			if ( yy >= sy ) { break; }
		}
	}


	return;
}

// internal
void
n_win_txtbox_draw_text( n_win_txtbox *p, HDC hdc, const n_posix_char *str, n_type_int cch, RECT *rect, int dt )
{
//return;

	if ( cch > INT_MAX ) { return; }

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{

#ifdef UNICODE
		n_posix_char *s = n_string_carboncopy ( str );
#else  // #ifdef UNICODE
		     wchar_t *s = n_posix_ansi2unicode( str ); cch = -1;
#endif // #ifdef UNICODE

		//p->uxtheme.DrawThemeText( p->uxtheme.htheme, hdc, 0,0, s,cch, dt,0, rect );

		{

			// [!] : Win8 or later : effect will be ignored

			DTTOPTS dttopts; ZeroMemory( &dttopts, sizeof( DTTOPTS ) );

			dttopts.dwSize  = sizeof( DTTOPTS );
			dttopts.dwFlags = DTT_COMPOSITED;

			dttopts.dwFlags = dttopts.dwFlags | DTT_TEXTCOLOR;
			dttopts.crText  = p->color___dwm_contour;

			// [x] : buggy

			n_type_gfx x = -p->scale;
			n_type_gfx y = -p->scale;
			n_posix_loop
			{break;

				if ( ( x == 0 )&&( y == 0 ) )
				{
					//
				} else {
					RECT r = { rect->left + x, rect->top + y, rect->right + x, rect->bottom + y };
					p->uxtheme.DrawThemeTextEx( p->uxtheme.htheme, hdc, 0,0, s, (int) cch, dt, &r, &dttopts );
				}

				x++;
				if ( x > p->scale )
				{
					x = -p->scale;

					y++;
					if ( y > p->scale ) { break; }
				}
			}

			dttopts.crText = p->color___dwm_textclr;

			p->uxtheme.DrawThemeTextEx( p->uxtheme.htheme, hdc, 0,0, s, (int) cch, dt, rect, &dttopts );

		}

		n_string_free( s );

	} else {

		DrawText( hdc, str, (int) cch, rect, dt );
		//ExtTextOut( hdc, rect->left, rect->top, 0, rect, str, cch, NULL );

		// [Needed] : Win9x

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			n_type_gfx x,y,sx,sy; n_win_rect_expand_range( rect, &x,&y,&sx,&sy );

			x = n_posix_max( x, p->border_pxl_sx + p->pad_pxl_sx );

			ExcludeClipRect( hdc, x, y, sx, sy );
		}

	}


	return;
}


