// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lcomctl32


// [x] : you need to process WM_SETTINGCHANGE
//
//	these will happen
//
//	a : old color will be used without sending WM_SETTINGCHANGE
//	b : old height will be used without sending WM_SIZE
//	c : WM_SIZE causes automatic moving onto bottom of a parent window




#ifndef _H_NONNON_WIN32_WIN_STATUSBAR
#define _H_NONNON_WIN32_WIN_STATUSBAR




#include "./win.c"




#include <commctrl.h>

#ifdef _MSC_VER
#pragma comment( lib, "comctl32" )
#endif // #ifdef _MSC_VER




// for easy to read/replace

#define nwstb_text_set     n_win_statusbar_text_set
#define nwstb_resize       n_win_statusbar_resize
#define nwstb_size_get     n_win_statusbar_size_get
#define nwstb_gui          n_win_statusbar_gui
#define nwstb_gui_literal  n_win_statusbar_gui
#define nwstb_stdfont_init n_win_statusbar_stdfont_init
#define nwstb_stdfont_exit n_win_statusbar_stdfont_exit




void
n_win_statusbar_text_set( HWND hgui, int index, n_posix_char *str )
{

	// [Mechanism] : use "\t" for alignment
	//
	//	""     : left
	//	"\t"   : center
	//	"\t\t" : right


	n_win_message_send( hgui, SB_SETTEXT, index, str );


	return;
}

void
n_win_statusbar_resize( HWND hgui, int parts, n_posix_bool autosize )
{

	if ( autosize )
	{

		// [!] : XP : don't use MoveWindow()
		//
		//	Edit's border will disappear

		n_win_message_send( hgui, WM_SIZE, 0,0 );

	}


	// [!] : avoid zero division

	if ( parts == 0 ) { return; }


	HWND  hwnd = GetParent( hgui );
	RECT     r; GetClientRect( hwnd, &r );
	int   unit = r.right / parts;
	int  *size = n_memory_new_closed( parts * sizeof( int ) );


	int i = 0;
	n_posix_loop
	{

		size[ i ] = unit * ( 1 + i );


		i++;
		if ( i >= parts ) { break; }
	}

	n_win_message_send( hgui, SB_SETPARTS, parts, size );


	n_memory_free_closed( size );


	return;
}

n_type_gfx
n_win_statusbar_size_get( HWND hgui )
{

	n_type_gfx sy; n_win_size( hgui, NULL, &sy );


	return sy;
}

void
n_win_statusbar_gui( HWND hwnd_parent, int sizegrip, HWND *hgui )
{

	// [!] : SBARS_SIZEGRIP need to set at CreateStatusWindow()


	InitCommonControls();


	if ( sizegrip ) { sizegrip = SBARS_SIZEGRIP; } else { sizegrip = 0; }


	(*hgui) = CreateStatusWindow
	(
		WS_CHILD | WS_VISIBLE | sizegrip,
		N_STRING_EMPTY,
		hwnd_parent,
		0
	);

	n_win_font_default( (*hgui), n_posix_false );


	return;
}

void
n_win_statusbar_stdfont_init( HWND hgui )
{

	NONCLIENTMETRICS ncm;
	int              cb = sizeof( NONCLIENTMETRICS );

	ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;
	int ret = SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );
	if ( ret == n_posix_false ) { return; }


	n_win_font_exit( n_win_font_get( hgui ) );
	n_win_font_set( hgui, n_win_font_logfont2hfont( &ncm.lfStatusFont ), n_posix_false );


	n_win_message_send( hgui, WM_SETTINGCHANGE, 0,0 );
	n_win_message_send( hgui, WM_SIZE,          0,0 );


	return;
}

void
n_win_statusbar_stdfont_exit( HWND hgui )
{

	n_win_font_exit( n_win_font_get( hgui ) );


	return;
}


#endif // _H_NONNON_WIN32_WIN_STATUSBAR

