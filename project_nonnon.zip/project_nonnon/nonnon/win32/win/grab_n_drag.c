// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : not implemented intentionally
//
//	[ Cursor ]
//
//	n_win_cursor_add( hwnd or NULL, IDC_SIZEALL );
//
//	[ Capture ]
//
//	SetCapture( hwnd ); / ReleaseCature();


// [!] : inertia / friction support
//
//	set n_posix_true with .inertia_onoff after n_win_grab_n_drag_init() is called
//
//	step needs to be calculated




#ifndef _H_NONNON_WIN32_WIN_GRAB_N_DRAG
#define _H_NONNON_WIN32_WIN_GRAB_N_DRAG




#include "./timer.c"




typedef struct {

	n_posix_bool onoff;
	POINT        cursor_prv;

	HWND         hwnd_parent;

	// [!] : inertia support : currently experimental

	n_posix_bool inertia_onoff;
	UINT         timer_id;
	u32          interval;
	int          x;
	int          y;
	int          step_x;
	int          step_y;
	u32          tick;
	u32          last_time;

} n_win_grab_n_drag;


#define n_win_grab_n_drag_zero( p ) n_memory_zero( p, sizeof( n_win_grab_n_drag ) )




inline n_posix_bool
n_win_grab_n_drag_timer( u32 *prv, u32 interval )
{

	// [!] : this is the same of game/helper.c


	u32 cur = n_posix_tickcount();
	u32 msec;


	if ( (*prv) > cur )
	{
		msec = cur + ( 0xffff - (*prv) );
	} else {
		msec = cur - (*prv);
	}

	if ( msec >= interval )
	{
		(*prv) = cur;

		return n_posix_true;
	}


	return n_posix_false;
}

int
n_win_grab_n_drag_clamp( int target, int v )
{

	if ( target < 0 )
	{
		v = n_posix_min( target, v );
	} else
	if ( target > 0 )
	{
		v = n_posix_max( target, v );
	}

	return v;
}

int
n_win_grab_n_drag_stepping( int target, int step )
{

	if ( target < 0 )
	{
		target += step;
		if ( target > 0 ) { target = 0; }
	} else
	if ( target > 0 )
	{
		target -= step;
		if ( target < 0 ) { target = 0; }
	}

	return target;
}




void
n_win_grab_n_drag_init( n_win_grab_n_drag *p, HWND hwnd_parent )
{
//return;

	// [!] : WM_MBUTTONDOWN


	GetCursorPos( &p->cursor_prv );

	static UINT timer_id = 0;
	if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

	p->onoff       = n_posix_true;
	p->hwnd_parent = hwnd_parent;

	p->timer_id    = timer_id;
	p->interval    = 66;
	p->x           = 0;
	p->y           = 0;
	p->step_x      = 1;
	p->step_y      = 1;


	return;
}

n_posix_bool
n_win_grab_n_drag_loop( n_win_grab_n_drag *p, int *delta_x, int *delta_y )
{
//return n_posix_true;

	// [!] : WM_MOUSEMOVE


	if ( p->onoff == n_posix_false ) { return n_posix_true; }


	POINT cur; GetCursorPos( &cur );

	int dx = p->cursor_prv.x - cur.x;
	int dy = p->cursor_prv.y - cur.y;

	if ( delta_x != NULL ) { (*delta_x) = dx; }
	if ( delta_y != NULL ) { (*delta_y) = dy; }

	p->x = n_win_grab_n_drag_clamp( dx, p->x );
	p->y = n_win_grab_n_drag_clamp( dy, p->y );
//n_win_hwndprintf_literal( p->hwnd_parent, " %d %d ", p->x, p->y );

	p->last_time = n_posix_tickcount();

	p->cursor_prv = cur;


	return n_posix_false;
}

void
n_win_grab_n_drag_exit( n_win_grab_n_drag *p )
{
//return;

	// [!] : WM_MBUTTONUP

	// [!] : WM_MOUSEACTIVATE : for IWebBrowser2


	p->onoff = n_posix_false;


	// [x] : flaky

	p->inertia_onoff = n_posix_false;

	if ( p->inertia_onoff == n_posix_false ) { return; }


	if ( ( p->last_time + 50 ) < n_posix_tickcount() ) { return; }

	n_win_timer_init( p->hwnd_parent, p->timer_id, 10 );

	p->tick = n_posix_tickcount();


	return;
}

n_posix_bool
n_win_grab_n_drag_inertia( n_win_grab_n_drag *p, WPARAM wparam, int *delta_x, int *delta_y )
{

	// [!] : WM_TIMER


	if ( wparam == 0 ) { return n_posix_true; }

	if ( wparam != p->timer_id ) { return n_posix_true; }


	if ( n_win_grab_n_drag_timer( &p->tick, p->interval ) )
	{
		if ( p->step_x < 1 ) { p->step_x = 1; }
		if ( p->step_y < 1 ) { p->step_y = 1; }

		p->x = n_win_grab_n_drag_stepping( p->x, p->step_x );
		p->y = n_win_grab_n_drag_stepping( p->y, p->step_y );
	}

	if ( delta_x != NULL ) { (*delta_x) = p->x; }
	if ( delta_y != NULL ) { (*delta_y) = p->y; }

	if ( ( p->x == 0 )&&( p->y == 0 ) )
	{
		n_win_timer_exit( p->hwnd_parent, p->timer_id );

		return n_posix_true;
	}


	return n_posix_false;
}




#endif // _H_NONNON_WIN32_WIN_GRAB_N_DRAG

