// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_SYSINFO_DRIVE
#define _H_NONNON_WIN32_SYSINFO_DRIVE




#include "../../neutral/posix.c"




void
n_sysinfo_drive_name( const n_posix_char *name, n_posix_char *ret, DWORD ret_len )
{

	GetVolumeInformation( name, ret,ret_len, NULL, NULL,NULL, 0,0 );


	return;
}

u32
n_sysinfo_drive_type( const n_posix_char *name )
{
	return GetDriveType( name );
}

u32
n_sysinfo_drive_info( const n_posix_char *name )
{

	u32 info = 0; GetVolumeInformation( name, NULL,0, NULL,NULL, &info, NULL,0 );


	return info;
}

n_posix_bool
n_sysinfo_drive_is_empty( const n_posix_char *name )
{

	if (
		( DRIVE_NO_ROOT_DIR != n_sysinfo_drive_type( name ) )
		&&
		( 0 == n_sysinfo_drive_info( name ) )
	)
	{
		return n_posix_true;
	}


	return n_posix_false;
}

void
n_sysinfo_drive_size( const n_posix_char *name, u64 *disksize, u64 *freesize )
{

	// [x] : error dialog will appear when ejected
	//
	//	use n_sysinfo_drive_is_empty() to check


	// [!] : Win95a and WinNT4.0 hasn't GetDiskFreeSpaceEx()
	//
	//	WinNT4.0 crashes when call

	//GetDiskFreeSpaceEx( name, NULL, (void*) disksize, (void*) freesize );


	DWORD sector_per_cluster = 0;
	DWORD byte_per_sector    = 0;
	DWORD free_cluster       = 0;
	DWORD total_cluster      = 0;

	GetDiskFreeSpace( name, &sector_per_cluster, &byte_per_sector, &free_cluster, &total_cluster );

	if ( disksize != NULL ) { (*disksize) = (u64) total_cluster * sector_per_cluster * byte_per_sector; }
	if ( freesize != NULL ) { (*freesize) = (u64)  free_cluster * sector_per_cluster * byte_per_sector; }


	return;
}


#endif // _H_NONNON_WIN32_SYSINFO_DRIVE


