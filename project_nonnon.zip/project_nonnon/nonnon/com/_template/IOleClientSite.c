// Nonnon COM : IOleClientSite
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed




#ifndef _H_NONNON_WIN32_COM_IOLECLIENTSITE
#define _H_NONNON_WIN32_COM_IOLECLIENTSITE




//#include "./AmbientProperty.c"
//#include "./IOleContainer.c"
#include "./IOleInPlaceSite.c"
//#include "./IServiceProvider.c"




HRESULT __stdcall
n_IOleClientSite_IUnknown_QueryInterface( IOleClientSite *_this, REFIID iid, void **ppvObject )
{
//n_com_debug_a( "IOleClientSite_IUnknown_QueryInterface" );


	// [Mechanism]
	//
	//	{6D5140C1-7436-11CE-8034-00AA006009FA} : IServiceProvider 
	//	{00000119-0000-0000-C000-000000000046} : IOleInPlaceSite
	//	{00020400-0000-0000-C000-000000000046} : IDispatch

	//n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID c = n_com_guid( n_guid_IID_IOleClientSite );
	GUID i = n_com_guid( n_guid_IID_IOleInPlaceSite );

	GUID d = n_com_guid( n_guid_IID_IDispatch );
	GUID s = n_com_guid( n_guid_IID_IServiceProvider );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &c ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;

	} else
	if ( IsEqualGUID( iid, &i ) )
	{

		(*ppvObject) = (void*) &n_IOleInPlaceSite_instance;

		return S_OK;

	} else
	if ( IsEqualGUID( iid, &d ) )
	{

#ifdef _H_NONNON_WIN32_COM_AMBIENTPROPERTY

		// [x] : crash

		(*ppvObject) = (void*) &n_AmbientProperty_instance;

		return S_OK;

#endif // #ifdef _H_NONNON_WIN32_COM_AMBIENTPROPERTY

	} else
	if ( IsEqualGUID( iid, &s ) )
	{

#ifdef _H_NONNON_WIN32_COM_ISERVICEPROVIDER

		// [x] : crash

		(*ppvObject) = (void*) &n_IServiceProvider_instance;

		return S_OK;

#endif // #ifdef _H_NONNON_WIN32_COM_ISERVICEPROVIDER

	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_IOleClientSite_SaveObject( IOleClientSite *_this )
{
n_com_debug_a( "IOleClientSite_SaveObject" );

	return E_FAIL;
}

HRESULT __stdcall
n_IOleClientSite_GetMoniker( IOleClientSite *_this, DWORD dwAssign, DWORD dwWhichMoniker, IMoniker **ppmk )
{
n_com_debug_a( "IOleClientSite_GetMoniker" );


	//typedef enum tagOLEGETMONIKER
	//{
	//    OLEGETMONIKER_ONLYIFTHERE    = 1,
	//    OLEGETMONIKER_FORCEASSIGN    = 2,
	//    OLEGETMONIKER_UNASSIGN       = 3,
	//    OLEGETMONIKER_TEMPFORUSER    = 4 
	//} OLEGETMONIKER;


	switch( dwAssign ) {

	case OLEGETMONIKER_ONLYIFTHERE :
n_com_debug_a( "IOleClientSite_GetMoniker : dwAssign : OLEGETMONIKER_ONLYIFTHERE" );

	break;

	case OLEGETMONIKER_FORCEASSIGN :
n_com_debug_a( "IOleClientSite_GetMoniker : dwAssign : OLEGETMONIKER_FORCEASSIGN" );

	break;

	case OLEGETMONIKER_UNASSIGN :
n_com_debug_a( "IOleClientSite_GetMoniker : dwAssign : OLEGETMONIKER_UNASSIGN" );

	break;

	case OLEGETMONIKER_TEMPFORUSER :
n_com_debug_a( "IOleClientSite_GetMoniker : dwAssign : OLEGETMONIKER_TEMPFORUSER" );

	break;

	} // switch


	//typedef enum tagOLEWHICHMK 
	//{ 
	//    OLEWHICHMK_CONTAINER    = 1, 
	//    OLEWHICHMK_OBJREL       = 2, 
	//    OLEWHICHMK_OBJFULL      = 3 
	//} OLEWHICHMK; 


	switch( dwWhichMoniker ) {

	case OLEWHICHMK_CONTAINER :
n_com_debug_a( "IOleClientSite_GetMoniker : dwAssign : OLEWHICHMK_CONTAINER" );

	break;

	case OLEWHICHMK_OBJREL :
n_com_debug_a( "IOleClientSite_GetMoniker : dwAssign : OLEWHICHMK_OBJREL" );

	break;

	case OLEWHICHMK_OBJFULL :
n_com_debug_a( "IOleClientSite_GetMoniker : dwAssign : OLEWHICHMK_OBJFULL" );

	} // switch


	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleClientSite_GetContainer( IOleClientSite *_this, IOleContainer **ppContainer )
{
n_com_debug_a( "IOleClientSite_GetContainer" );


	if ( ppContainer == NULL ) { return E_POINTER; } else { (*ppContainer) = NULL; }


#ifdef _H_NONNON_WIN32_COM_IOLECONTAINER

	// [!] : not needed

	(*ppContainer) = &n_IOleContainer_instance;
	return S_OK;

#endif // #ifdef _H_NONNON_WIN32_COM_IOLECONTAINER


	return E_NOINTERFACE;
}

HRESULT __stdcall
n_IOleClientSite_ShowObject( IOleClientSite *_this )
{
n_com_debug_a( "IOleClientSite_ShowObject" );

	return NOERROR;
}

HRESULT __stdcall
n_IOleClientSite_OnShowWindow( IOleClientSite *_this, BOOL fShow )
{
n_com_debug_a( "IOleClientSite_OnShowWindow" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleClientSite_RequestNewObjectLayout( IOleClientSite *_this )
{
n_com_debug_a( "IOleClientSite_RequestNewObjectLayout" );

	return E_NOTIMPL;
}




const void *n_IOleClientSite_Vtbl[] = {

	n_IOleClientSite_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IOleClientSite_SaveObject,
	n_IOleClientSite_GetMoniker,
	n_IOleClientSite_GetContainer,
	n_IOleClientSite_ShowObject,
	n_IOleClientSite_OnShowWindow,
	n_IOleClientSite_RequestNewObjectLayout,

};


IOleClientSite n_IOleClientSite_instance = { (void*) n_IOleClientSite_Vtbl };




#endif // _H_NONNON_WIN32_COM_IOLECLIENTSITE

