// Nonnon COM : Patch for Missing Symbols
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_COM_PATCH
#define _H_NONNON_WIN32_COM_PATCH




// Template
/*
#define IUnknown_QueryInterface(    p, a,b             ) (p)->lpVtbl->QueryInterface(   p, a,b             )
#define IUnknown_AddRef(            p                  ) (p)->lpVtbl->AddRef(           p                  )
#define IUnknown_Release(           p                  ) (p)->lpVtbl->Release(          p                  )

#define IDispatch_GetTypeInfoCount( p, a               ) (p)->lpVtbl->GetTypeInfoCount( p, a               )
#define IDispatch_GetTypeInfo(      p, a,b,c           ) (p)->lpVtbl->GetTypeInfo(      p, a,b,c           )
#define IDispatch_GetIDsOfNames(    p, a,b,c,d,e       ) (p)->lpVtbl->GetIDsOfNames(    p, a,b,c,d,e       )
#define IDispatch_Invoke(           p, a,b,c,d,e,f,g,h ) (p)->lpVtbl->Invoke(           p, a,b,c,d,e,f,g,h )
*/



// docobj.h

// [!] : mshtmcid.h mshtmhst.h use this

#include <docobj.h>


// [!] : MinGW's enum OLECMDID has 30 items only

#define OLECMDID_ONTOOLBARACTIVATED             31
#define OLECMDID_FIND                           32
#define OLECMDID_DELETE                         33
#define OLECMDID_HTTPEQUIV                      34
#define OLECMDID_HTTPEQUIV_DONE                 35
#define OLECMDID_ENABLE_INTERACTION             36
#define OLECMDID_ONUNLOAD                       37
#define OLECMDID_PROPERTYBAG2                   38
#define OLECMDID_PREREFRESH                     39
#define OLECMDID_SHOWSCRIPTERROR                40
#define OLECMDID_SHOWMESSAGE                    41
#define OLECMDID_SHOWFIND                       42
#define OLECMDID_SHOWPAGESETUP                  43
#define OLECMDID_SHOWPRINT                      44
#define OLECMDID_CLOSE                          45
#define OLECMDID_ALLOWUILESSSAVEAS              46
#define OLECMDID_DONTDOWNLOADCSS                47
#define OLECMDID_UPDATEPAGESTATUS               48
#define OLECMDID_PRINT2                         49
#define OLECMDID_PRINTPREVIEW2                  50
#define OLECMDID_SETPRINTTEMPLATE               51
#define OLECMDID_GETPRINTTEMPLATE               52
#define OLECMDID_PAGEACTIONBLOCKED              55
#define OLECMDID_PAGEACTIONUIQUERY              56
#define OLECMDID_FOCUSVIEWCONTROLS              57
#define OLECMDID_FOCUSVIEWCONTROLSQUERY         58
#define OLECMDID_SHOWPAGEACTIONMENU             59
#define OLECMDID_ADDTRAVELENTRY                 60
#define OLECMDID_UPDATETRAVELENTRY              61
#define OLECMDID_UPDATEBACKFORWARDSTATE         62
#define OLECMDID_OPTICAL_ZOOM                   63
#define OLECMDID_OPTICAL_GETZOOMRANGE           64
#define OLECMDID_WINDOWSTATECHANGED             65
#define OLECMDID_ACTIVEXINSTALLSCOPE            66
#define OLECMDID_UPDATETRAVELENTRY_DATARECOVERY 67


#define HTMLID_FIND        1
#define HTMLID_VIEWSOURCE  2
#define HTMLID_OPTIONS     3


#define IOleCommandTarget_QueryStatus( p, a,b,c,d   ) (p)->lpVtbl->QueryStatus( p, a,b,c,d   )
#define IOleCommandTarget_Exec(        p, a,b,c,d,e ) (p)->lpVtbl->Exec(        p, a,b,c,d,e )





// exdisp.h : these macros are from the wine project

#define IWebBrowser_QueryInterface   IUnknown_QueryInterface
#define IWebBrowser_AddRef           IUnknown_AddRef
#define IWebBrowser_Release          IUnknown_Release
#define IWebBrowser_GetTypeInfoCount IDispatch_GetTypeInfoCount
#define IWebBrowser_GetTypeInfo      IDispatch_GetTypeInfo
#define IWebBrowser_GetIDsOfNames    IDispatch_GetIDsOfNames
#define IWebBrowser_Invoke           IDispatch_Invoke

#define IWebBrowser_GoBack(                p            ) (p)->lpVtbl->GoBack(                p            )
#define IWebBrowser_GoForward(             p            ) (p)->lpVtbl->GoForward(             p            )
#define IWebBrowser_GoHome(                p            ) (p)->lpVtbl->GoHome(                p            )
#define IWebBrowser_GoSearch(              p            ) (p)->lpVtbl->GoSearch(              p            )
#define IWebBrowser_Navigate(              p, a,b,c,d,e ) (p)->lpVtbl->Navigate(              p, a,b,c,d,e )
#define IWebBrowser_Refresh(               p            ) (p)->lpVtbl->Refresh(               p            )
#define IWebBrowser_Refresh2(              p, a         ) (p)->lpVtbl->Refresh2(              p, a         )
#define IWebBrowser_Stop(                  p            ) (p)->lpVtbl->Stop(                  p            )
#define IWebBrowser_get_Application(       p, a         ) (p)->lpVtbl->get_Application(       p, a         )
#define IWebBrowser_get_Parent(            p, a         ) (p)->lpVtbl->get_Parent(            p, a         )
#define IWebBrowser_get_Container(         p, a         ) (p)->lpVtbl->get_Container(         p, a         )
#define IWebBrowser_get_Document(          p, a         ) (p)->lpVtbl->get_Document(          p, a         )
#define IWebBrowser_get_TopLevelContainer( p, a         ) (p)->lpVtbl->get_TopLevelContainer( p, a         )
#define IWebBrowser_get_Type(              p, a         ) (p)->lpVtbl->get_Type(              p, a         )
#define IWebBrowser_get_Left(              p, a         ) (p)->lpVtbl->get_Left(              p, a         )
#define IWebBrowser_put_Left(              p, a         ) (p)->lpVtbl->put_Left(              p, a         )
#define IWebBrowser_get_Top(               p, a         ) (p)->lpVtbl->get_Top(               p, a         )
#define IWebBrowser_put_Top(               p, a         ) (p)->lpVtbl->put_Top(               p, a         )
#define IWebBrowser_get_Width(             p, a         ) (p)->lpVtbl->get_Width(             p, a         )
#define IWebBrowser_put_Width(             p, a         ) (p)->lpVtbl->put_Width(             p, a         )
#define IWebBrowser_get_Height(            p, a         ) (p)->lpVtbl->get_Height(            p, a         )
#define IWebBrowser_put_Height(            p, a         ) (p)->lpVtbl->put_Height(            p, a         )
#define IWebBrowser_get_LocationName(      p, a         ) (p)->lpVtbl->get_LocationName(      p, a         )
#define IWebBrowser_get_LocationURL(       p, a         ) (p)->lpVtbl->get_LocationURL(       p, a         )
#define IWebBrowser_get_Busy(              p, a         ) (p)->lpVtbl->get_Busy(              p, a         )


#define IWebBrowser2_QueryInterface   IUnknown_QueryInterface
#define IWebBrowser2_AddRef           IUnknown_AddRef
#define IWebBrowser2_Release          IUnknown_Release
#define IWebBrowser2_GetTypeInfoCount IDispatch_GetTypeInfoCount
#define IWebBrowser2_GetTypeInfo      IDispatch_GetTypeInfo
#define IWebBrowser2_GetIDsOfNames    IDispatch_GetIDsOfNames
#define IWebBrowser2_Invoke           IDispatch_Invoke

#define IWebBrowser2_GoBack                IWebBrowser_GoBack
#define IWebBrowser2_GoForward             IWebBrowser_GoForward
#define IWebBrowser2_GoHome                IWebBrowser_GoHome
#define IWebBrowser2_GoSearch              IWebBrowser_GoSearch
#define IWebBrowser2_Navigate              IWebBrowser_Navigate
#define IWebBrowser2_Refresh               IWebBrowser_Refresh
#define IWebBrowser2_Refresh2              IWebBrowser_Refresh2
#define IWebBrowser2_Stop                  IWebBrowser_Stop
#define IWebBrowser2_get_Application       IWebBrowser_get_Application
#define IWebBrowser2_get_Parent            IWebBrowser_get_Parent
#define IWebBrowser2_get_Container         IWebBrowser_get_Container
#define IWebBrowser2_get_Document          IWebBrowser_get_Document
#define IWebBrowser2_get_TopLevelContainer IWebBrowser_get_TopLevelContainer
#define IWebBrowser2_get_Type              IWebBrowser_get_Type
#define IWebBrowser2_get_Left              IWebBrowser_get_Left
#define IWebBrowser2_put_Left              IWebBrowser_put_Left
#define IWebBrowser2_get_Top               IWebBrowser_get_Top
#define IWebBrowser2_put_Top               IWebBrowser_put_Top
#define IWebBrowser2_get_Width             IWebBrowser_get_Width
#define IWebBrowser2_put_Width             IWebBrowser_put_Width
#define IWebBrowser2_get_Height            IWebBrowser_get_Height
#define IWebBrowser2_put_Height            IWebBrowser_put_Height
#define IWebBrowser2_get_LocationName      IWebBrowser_get_LocationName
#define IWebBrowser2_get_LocationURL       IWebBrowser_get_LocationURL
#define IWebBrowser2_get_Busy              IWebBrowser_get_Busy

#define IWebBrowser2_Quit(                     p            ) (p)->lpVtbl->Quit(                     p            )
#define IWebBrowser2_ClientToWindow(           p, a,b       ) (p)->lpVtbl->ClientToWindow(           p, a,b       )
#define IWebBrowser2_PutProperty(              p, a,b       ) (p)->lpVtbl->PutProperty(              p, a,b       )
#define IWebBrowser2_GetProperty(              p, a,b       ) (p)->lpVtbl->GetProperty(              p, a,b       )
#define IWebBrowser2_get_Name(                 p, a         ) (p)->lpVtbl->get_Name(                 p, a         )
#define IWebBrowser2_get_HWND(                 p, a         ) (p)->lpVtbl->get_HWND(                 p, a         )
#define IWebBrowser2_get_FullName(             p, a         ) (p)->lpVtbl->get_FullName(             p, a         )
#define IWebBrowser2_get_Path(                 p, a         ) (p)->lpVtbl->get_Path(                 p, a         )
#define IWebBrowser2_get_Visible(              p, a         ) (p)->lpVtbl->get_Visible(              p, a         )
#define IWebBrowser2_put_Visible(              p, a         ) (p)->lpVtbl->put_Visible(              p, a         )
#define IWebBrowser2_get_StatusBar(            p, a         ) (p)->lpVtbl->get_StatusBar(            p, a         )
#define IWebBrowser2_put_StatusBar(            p, a         ) (p)->lpVtbl->put_StatusBar(            p, a         )
#define IWebBrowser2_get_StatusText(           p, a         ) (p)->lpVtbl->get_StatusText(           p, a         )
#define IWebBrowser2_put_StatusText(           p, a         ) (p)->lpVtbl->put_StatusText(           p, a         )
#define IWebBrowser2_get_ToolBar(              p, a         ) (p)->lpVtbl->get_ToolBar(              p, a         )
#define IWebBrowser2_put_ToolBar(              p, a         ) (p)->lpVtbl->put_ToolBar(              p, a         )
#define IWebBrowser2_get_MenuBar(              p, a         ) (p)->lpVtbl->get_MenuBar(              p, a         )
#define IWebBrowser2_put_MenuBar(              p, a         ) (p)->lpVtbl->put_MenuBar(              p, a         )
#define IWebBrowser2_get_FullScreen(           p, a         ) (p)->lpVtbl->get_FullScreen(           p, a         )
#define IWebBrowser2_put_FullScreen(           p, a         ) (p)->lpVtbl->put_FullScreen(           p, a         )

#define IWebBrowser2_Navigate2(                p, a,b,c,d,e ) (p)->lpVtbl->Navigate2(                p, a,b,c,d,e )
#define IWebBrowser2_QueryStatusWB(            p, a,b       ) (p)->lpVtbl->QueryStatusWB(            p, a,b       )
#define IWebBrowser2_ExecWB(                   p, a,b,c,d   ) (p)->lpVtbl->ExecWB(                   p, a,b,c,d   )
#define IWebBrowser2_ShowBrowserBar(           p, a,b,c     ) (p)->lpVtbl->ShowBrowserBar(           p, a,b,c     )
#define IWebBrowser2_get_ReadyState(           p, a         ) (p)->lpVtbl->get_ReadyState(           p, a         )
#define IWebBrowser2_get_Offline(              p, a         ) (p)->lpVtbl->get_Offline(              p, a         )
#define IWebBrowser2_put_Offline(              p, a         ) (p)->lpVtbl->put_Offline(              p, a         )
#define IWebBrowser2_get_Silent(               p, a         ) (p)->lpVtbl->get_Silent(               p, a         )
#define IWebBrowser2_put_Silent(               p, a         ) (p)->lpVtbl->put_Silent(               p, a         )
#define IWebBrowser2_get_RegisterAsBrowser(    p, a         ) (p)->lpVtbl->get_RegisterAsBrowser(    p, a         )
#define IWebBrowser2_put_RegisterAsBrowser(    p, a         ) (p)->lpVtbl->put_RegisterAsBrowser(    p, a         )
#define IWebBrowser2_get_RegisterAsDropTarget( p, a         ) (p)->lpVtbl->get_RegisterAsDropTarget( p, a         )
#define IWebBrowser2_put_RegisterAsDropTarget( p, a         ) (p)->lpVtbl->put_RegisterAsDropTarget( p, a         )
#define IWebBrowser2_get_TheaterMode(          p, a         ) (p)->lpVtbl->get_TheaterMode(          p, a         )
#define IWebBrowser2_put_TheaterMode(          p, a         ) (p)->lpVtbl->put_TheaterMode(          p, a         )
#define IWebBrowser2_get_AddressBar(           p, a         ) (p)->lpVtbl->get_AddressBar(           p, a         )
#define IWebBrowser2_put_AddressBar(           p, a         ) (p)->lpVtbl->put_AddressBar(           p, a         )
#define IWebBrowser2_get_Resizable(            p, a         ) (p)->lpVtbl->get_Resizable(            p, a         )
#define IWebBrowser2_put_Resizable(            p, a         ) (p)->lpVtbl->put_Resizable(            p, a         )


EXTERN_C const IID IID_IShellWindows;
#define INTERFACE IShellWindows
DECLARE_INTERFACE_(IShellWindows,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD( get_Count           )( THIS_ long* ) PURE;
	STDMETHOD( Item                )( THIS_ VARIANT, IDispatch** ) PURE;
	STDMETHOD( _NewEnum            )( THIS_ IUnknown** ) PURE;
	STDMETHOD( Register            )( THIS_ IDispatch*, long, int, long* ) PURE;
	STDMETHOD( RegisterPending     )( THIS_ long, VARIANT*, VARIANT*, int, long* ) PURE;
	STDMETHOD( Revoke              )( THIS_ long ) PURE;
	STDMETHOD( OnNavigate          )( THIS_ long, VARIANT* ) PURE;
	STDMETHOD( OnActivated         )( THIS_ long, VARIANT* ) PURE;
	STDMETHOD( FindWindowSW        )( THIS_ VARIANT*, VARIANT*, int, long*, int, IDispatch** ) PURE;
	STDMETHOD( OnCreated           )( THIS_ long, IUnknown* ) PURE;
	STDMETHOD( ProcessAttachDetach )( THIS_ VARIANT_BOOL ) PURE;
};
#undef INTERFACE




// ocidl.h

#define IOleControl_QueryInterface(          p,a,b ) (p)->lpVtbl->QueryInterface(          p,a,b )
#define IOleControl_AddRef(                  p     ) (p)->lpVtbl->AddRef(                  p     )
#define IOleControl_Release(                 p     ) (p)->lpVtbl->Release(                 p     )
#define IOleControl_GetControlInfo(          p,a   ) (p)->lpVtbl->GetControlInfo(          p,a   )
#define IOleControl_OnMnemonic(              p,a   ) (p)->lpVtbl->OnMnemonic(              p,a   )
#define IOleControl_OnAmbientPropertyChange( p,a   ) (p)->lpVtbl->OnAmbientPropertyChange( p,a   )
#define IOleControl_FreezeEvents(            p,a   ) (p)->lpVtbl->FreezeEvents(            p,a   )




// olectl.h

#define DISPID_NORMAL_FIRST 1000




// oleidl.h

typedef enum tagOLEMISC {

	OLEMISC_RECOMPOSEONRESIZE            = 0x000001,
	OLEMISC_ONLYICONIC                   = 0x000002,
	OLEMISC_INSERTNOTREPLACE             = 0x000004,
	OLEMISC_STATIC                       = 0x000008,
	OLEMISC_CANTLINKINSIDE               = 0x000010,
	OLEMISC_CANLINKBYOLE1                = 0x000020,
	OLEMISC_ISLINKOBJECT                 = 0x000040,
	OLEMISC_INSIDEOUT                    = 0x000080,
	OLEMISC_ACTIVATEWHENVISIBLE          = 0x000100,
	OLEMISC_RENDERINGISDEVICEINDEPENDENT = 0x000200,
	OLEMISC_INVISIBLEATRUNTIME           = 0x000400,
	OLEMISC_ALWAYSRUN                    = 0x000800,
	OLEMISC_ACTSLIKEBUTTON               = 0x001000,
	OLEMISC_ACTSLIKELABEL                = 0x002000,
	OLEMISC_NOUIACTIVATE                 = 0x004000,
	OLEMISC_ALIGNABLE                    = 0x008000,
	OLEMISC_SIMPLEFRAME                  = 0x010000,
	OLEMISC_SETCLIENTSITEFIRST           = 0x020000,
	OLEMISC_IMEMODE                      = 0x040000,
	OLEMISC_IGNOREACTIVATEWHENVISIBLE    = 0x080000,
	OLEMISC_WANTSTOMENUMERGE             = 0x100000,
	OLEMISC_SUPPORTSMULTILEVELUNDO       = 0x200000

} OLEMISC;


typedef enum tagOLERENDER {

	OLERENDER_NONE   = 0,
	OLERENDER_DRAW   = 1,
	OLERENDER_FORMAT = 2,
	OLERENDER_ASIS   = 3

} OLERENDER, *LPOLERENDER;




// mshtml.h

#include <mshtml.h>

#define HTMLDocumentEvents IDispatch

#define SID_SHTMLWindow IID_IHTMLWindow2


#define IHTMLDocument2_get_all(                 p,a ) (p)->lpVtbl->get_all(                 p,a )
#define IHTMLDocument2_get_body(                p,a ) (p)->lpVtbl->get_body(                p,a )
#define IHTMLDocument2_get_activeElement(       p,a ) (p)->lpVtbl->get_activeElement(       p,a )
#define IHTMLDocument2_get_images(              p,a ) (p)->lpVtbl->get_images(              p,a )
#define IHTMLDocument2_get_applets(             p,a ) (p)->lpVtbl->get_applets(             p,a )
#define IHTMLDocument2_get_links(               p,a ) (p)->lpVtbl->get_links(               p,a )
#define IHTMLDocument2_get_forms(               p,a ) (p)->lpVtbl->get_forms(               p,a )
#define IHTMLDocument2_get_anchors(             p,a ) (p)->lpVtbl->get_anchors(             p,a )
#define IHTMLDocument2_put_title(               p,a ) (p)->lpVtbl->put_title(               p,a )
#define IHTMLDocument2_get_title(               p,a ) (p)->lpVtbl->get_title(               p,a )
#define IHTMLDocument2_get_scripts(             p,a ) (p)->lpVtbl->get_scripts(             p,a )
#define IHTMLDocument2_put_designMode(          p,a ) (p)->lpVtbl->put_designMode(          p,a )
#define IHTMLDocument2_get_designMode(          p,a ) (p)->lpVtbl->get_designMode(          p,a )
#define IHTMLDocument2_get_selection(           p,a ) (p)->lpVtbl->get_selection(           p,a )
#define IHTMLDocument2_get_readyState(          p,a ) (p)->lpVtbl->get_readyState(          p,a )
#define IHTMLDocument2_get_frames(              p,a ) (p)->lpVtbl->get_frames(              p,a )
#define IHTMLDocument2_get_embeds(              p,a ) (p)->lpVtbl->get_embeds(              p,a )
#define IHTMLDocument2_get_plugins(             p,a ) (p)->lpVtbl->get_plugins(             p,a )
#define IHTMLDocument2_put_alinkColor(          p,a ) (p)->lpVtbl->put_alinkColor(          p,a )
#define IHTMLDocument2_get_alinkColor(          p,a ) (p)->lpVtbl->get_alinkColor(          p,a )
#define IHTMLDocument2_put_bgColor(             p,a ) (p)->lpVtbl->put_bgColor(             p,a )
#define IHTMLDocument2_get_bgColor(             p,a ) (p)->lpVtbl->get_bgColor(             p,a )
#define IHTMLDocument2_put_fgColor(             p,a ) (p)->lpVtbl->put_fgColor(             p,a )
#define IHTMLDocument2_get_fgColor(             p,a ) (p)->lpVtbl->get_fgColor(             p,a )
#define IHTMLDocument2_put_linkColor(           p,a ) (p)->lpVtbl->put_linkColor(           p,a )
#define IHTMLDocument2_get_linkColor(           p,a ) (p)->lpVtbl->get_linkColor(           p,a )
#define IHTMLDocument2_put_vlinkColor(          p,a ) (p)->lpVtbl->put_vlinkColor(          p,a )
#define IHTMLDocument2_get_vlinkColor(          p,a ) (p)->lpVtbl->get_vlinkColor(          p,a )
#define IHTMLDocument2_get_referrer(            p,a ) (p)->lpVtbl->get_referrer(            p,a )
#define IHTMLDocument2_get_location(            p,a ) (p)->lpVtbl->get_location(            p,a )
#define IHTMLDocument2_get_lastModified(        p,a ) (p)->lpVtbl->get_lastModified(        p,a )
#define IHTMLDocument2_put_URL(                 p,a ) (p)->lpVtbl->put_URL(                 p,a )
#define IHTMLDocument2_get_URL(                 p,a ) (p)->lpVtbl->get_URL(                 p,a )
#define IHTMLDocument2_put_domain(              p,a ) (p)->lpVtbl->put_domain(              p,a )
#define IHTMLDocument2_get_domain(              p,a ) (p)->lpVtbl->get_domain(              p,a )
#define IHTMLDocument2_put_cookie(              p,a ) (p)->lpVtbl->put_cookie(              p,a )
#define IHTMLDocument2_get_cookie(              p,a ) (p)->lpVtbl->get_cookie(              p,a )
#define IHTMLDocument2_put_expands(             p,a ) (p)->lpVtbl->put_expands(             p,a )
#define IHTMLDocument2_get_expands(             p,a ) (p)->lpVtbl->get_expands(             p,a )
#define IHTMLDocument2_put_charset(             p,a ) (p)->lpVtbl->put_charset(             p,a )
#define IHTMLDocument2_get_charset(             p,a ) (p)->lpVtbl->get_charset(             p,a )
#define IHTMLDocument2_put_defaultCharset(      p,a ) (p)->lpVtbl->put_defaultCharset(      p,a )
#define IHTMLDocument2_get_defaultCharset(      p,a ) (p)->lpVtbl->get_defaultCharset(      p,a )
#define IHTMLDocument2_get_mimeType(            p,a ) (p)->lpVtbl->get_mimeType(            p,a )
#define IHTMLDocument2_get_fileSize(            p,a ) (p)->lpVtbl->get_fileSize(            p,a )
#define IHTMLDocument2_get_fileCreatedDate(     p,a ) (p)->lpVtbl->get_fileCreatedDate(     p,a )
#define IHTMLDocument2_get_fileModifiedDate(    p,a ) (p)->lpVtbl->get_fileModifiedDate(    p,a )
#define IHTMLDocument2_get_fileUpdatedDate(     p,a ) (p)->lpVtbl->get_fileUpdatedDate(     p,a )
#define IHTMLDocument2_get_security(            p,a ) (p)->lpVtbl->get_security(            p,a )
#define IHTMLDocument2_get_protocol(            p,a ) (p)->lpVtbl->get_protocol(            p,a )
#define IHTMLDocument2_get_nameProp(            p,a ) (p)->lpVtbl->get_nameProp(            p,a )
#define IHTMLDocument2_write(                   p,a ) (p)->lpVtbl->write(                   p,a )
#define IHTMLDocument2_writeln(                 p,a ) (p)->lpVtbl->writeln(                 p,a )
#define IHTMLDocument2_open(            p,a,b,c,d,e ) (p)->lpVtbl->open(            p,a,b,c,d,e )
#define IHTMLDocument2_close(                     p ) (p)->lpVtbl->close(                     p )
#define IHTMLDocument2_clear(                     p ) (p)->lpVtbl->clear(                     p )
#define IHTMLDocument2_queryCommandSupported( p,a,b ) (p)->lpVtbl->queryCommandSupported( p,a,b )
#define IHTMLDocument2_queryCommandEnabled(   p,a,b ) (p)->lpVtbl->queryCommandEnabled(   p,a,b )
#define IHTMLDocument2_queryCommandState(     p,a,b ) (p)->lpVtbl->queryCommandState(     p,a,b )
#define IHTMLDocument2_queryCommandIndeterm(  p,a,b ) (p)->lpVtbl->queryCommandIndeterm(  p,a,b )
#define IHTMLDocument2_queryCommandText(      p,a,b ) (p)->lpVtbl->queryCommandText(      p,a,b )
#define IHTMLDocument2_queryCommandValue(     p,a,b ) (p)->lpVtbl->queryCommandValue(     p,a,b )
#define IHTMLDocument2_execCommand(       p,a,b,c,d ) (p)->lpVtbl->execCommand(       p,a,b,c,d )
#define IHTMLDocument2_execCommandShowHelp( p,a,b,c ) (p)->lpVtbl->execCommandShowHelp( p,a,b,c )
#define IHTMLDocument2_createElement(         p,a,b ) (p)->lpVtbl->createElement(         p,a,b )
#define IHTMLDocument2_put_onhelp(              p,a ) (p)->lpVtbl->put_onhelp(              p,a )
#define IHTMLDocument2_get_onhelp(              p,a ) (p)->lpVtbl->get_onhelp(              p,a )
#define IHTMLDocument2_put_onclick(             p,a ) (p)->lpVtbl->put_onclick(             p,a )
#define IHTMLDocument2_get_onclick(             p,a ) (p)->lpVtbl->get_onclick(             p,a )
#define IHTMLDocument2_put_ondblclick(          p,a ) (p)->lpVtbl->put_ondblclick(          p,a )
#define IHTMLDocument2_get_ondblclick(          p,a ) (p)->lpVtbl->get_ondblclick(          p,a )
#define IHTMLDocument2_put_onkeyup(             p,a ) (p)->lpVtbl->put_onkeyup(             p,a )
#define IHTMLDocument2_get_onkeyup(             p,a ) (p)->lpVtbl->get_onkeyup(             p,a )
#define IHTMLDocument2_put_onkeydown(           p,a ) (p)->lpVtbl->put_onkeydown(           p,a )
#define IHTMLDocument2_get_onkeydown(           p,a ) (p)->lpVtbl->get_onkeydown(           p,a )
#define IHTMLDocument2_put_onkeypress(          p,a ) (p)->lpVtbl->put_onkeypress(          p,a )
#define IHTMLDocument2_get_onkeypress(          p,a ) (p)->lpVtbl->get_onkeypress(          p,a )
#define IHTMLDocument2_put_onmouseup(           p,a ) (p)->lpVtbl->put_onmouseup(           p,a )
#define IHTMLDocument2_get_onmouseup(           p,a ) (p)->lpVtbl->get_onmouseup(           p,a )
#define IHTMLDocument2_put_onmousedown(         p,a ) (p)->lpVtbl->put_onmousedown(         p,a )
#define IHTMLDocument2_get_onmousedown(         p,a ) (p)->lpVtbl->get_onmousedown(         p,a )
#define IHTMLDocument2_put_onmousemove(         p,a ) (p)->lpVtbl->put_onmousemove(         p,a )
#define IHTMLDocument2_get_onmousemove(         p,a ) (p)->lpVtbl->get_onmousemove(         p,a )
#define IHTMLDocument2_put_onmouseout(          p,a ) (p)->lpVtbl->put_onmouseout(          p,a )
#define IHTMLDocument2_get_onmouseout(          p,a ) (p)->lpVtbl->get_onmouseout(          p,a )
#define IHTMLDocument2_put_onmouseover(         p,a ) (p)->lpVtbl->put_onmouseover(         p,a )
#define IHTMLDocument2_get_onmouseover(         p,a ) (p)->lpVtbl->get_onmouseover(         p,a )
#define IHTMLDocument2_put_onreadystatechange(  p,a ) (p)->lpVtbl->put_onreadystatechange(  p,a )
#define IHTMLDocument2_get_onreadystatechange(  p,a ) (p)->lpVtbl->get_onreadystatechange(  p,a )
#define IHTMLDocument2_put_onafterupdate(       p,a ) (p)->lpVtbl->put_onafterupdate(       p,a )
#define IHTMLDocument2_get_onafterupdate(       p,a ) (p)->lpVtbl->get_onafterupdate(       p,a )
#define IHTMLDocument2_put_onrowexit(           p,a ) (p)->lpVtbl->put_onrowexit(           p,a )
#define IHTMLDocument2_get_onrowexit(           p,a ) (p)->lpVtbl->get_onrowexit(           p,a )
#define IHTMLDocument2_put_onrowenter(          p,a ) (p)->lpVtbl->put_onrowenter(          p,a )
#define IHTMLDocument2_get_onrowenter(          p,a ) (p)->lpVtbl->get_onrowenter(          p,a )
#define IHTMLDocument2_put_ondragstart(         p,a ) (p)->lpVtbl->put_ondragstart(         p,a )
#define IHTMLDocument2_get_ondragstart(         p,a ) (p)->lpVtbl->get_ondragstart(         p,a )
#define IHTMLDocument2_put_onselectstart(       p,a ) (p)->lpVtbl->put_onselectstart(       p,a )
#define IHTMLDocument2_get_onselectstart(       p,a ) (p)->lpVtbl->get_onselectstart(       p,a )
#define IHTMLDocument2_elementFromPoint(    p,a,b,c ) (p)->lpVtbl->elementFromPoint(    p,a,b,c )
#define IHTMLDocument2_get_parentWindow(        p,a ) (p)->lpVtbl->get_parentWindow(        p,a )
#define IHTMLDocument2_get_styleSheets(         p,a ) (p)->lpVtbl->get_styleSheets(         p,a )
#define IHTMLDocument2_get_onbeforeupdate(      p,a ) (p)->lpVtbl->get_onbeforeupdate(      p,a )
#define IHTMLDocument2_put_onbeforeupdate(      p,a ) (p)->lpVtbl->put_onbeforeupdate(      p,a )
#define IHTMLDocument2_get_onerrorupdate(       p,a ) (p)->lpVtbl->get_onerrorupdate(       p,a )
#define IHTMLDocument2_put_onerrorupdate(       p,a ) (p)->lpVtbl->put_onerrorupdate(       p,a )
#define IHTMLDocument2_toString(                p,a ) (p)->lpVtbl->toString(                p,a )
#define IHTMLDocument2_createStyleSheet(    p,a,b,c ) (p)->lpVtbl->createStyleSheet(    p,a,b,c )


#define IHTMLSelectionObject_createRange( p,a ) (p)->lpVtbl->createRange( p,a )
#define IHTMLSelectionObject_empty(       p   ) (p)->lpVtbl->empty(       p   )
#define IHTMLSelectionObject_clear(       p   ) (p)->lpVtbl->clear(       p   )
#define IHTMLSelectionObject_get_type(    p,a ) (p)->lpVtbl->get_type(    p,a )


#define IHTMLTxtRange_get_htmlText(          p,a       ) (p)->lpVtbl->get_htmlText(          p,a       )
#define IHTMLTxtRange_put_text(              p,a       ) (p)->lpVtbl->put_text(              p,a       )
#define IHTMLTxtRange_get_text(              p,a       ) (p)->lpVtbl->get_text(              p,a       )
#define IHTMLTxtRange_parentElement(         p,a       ) (p)->lpVtbl->parentElement(         p,a       )
#define IHTMLTxtRange_duplicate(             p,a       ) (p)->lpVtbl->duplicate(             p,a       )
#define IHTMLTxtRange_inRange(               p,a,b     ) (p)->lpVtbl->inRange(               p,a,b     )
#define IHTMLTxtRange_isEqual(               p,a,b     ) (p)->lpVtbl->isEqual(               p,a,b     )
#define IHTMLTxtRange_scrollIntoView(        p,a       ) (p)->lpVtbl->scrollIntoView(        p,a       )
#define IHTMLTxtRange_collapse(              p,a       ) (p)->lpVtbl->collapse(              p,a       )
#define IHTMLTxtRange_expand(                p,a,b     ) (p)->lpVtbl->expand(                p,a,b     )
#define IHTMLTxtRange_move(                  p,a,b     ) (p)->lpVtbl->move(                  p,a,b     )
#define IHTMLTxtRange_moveStart(             p,a,b     ) (p)->lpVtbl->moveStart(             p,a,b     )
#define IHTMLTxtRange_moveEnd(               p,a,b     ) (p)->lpVtbl->moveEnd(               p,a,b     )
#define IHTMLTxtRange_select(                p         ) (p)->lpVtbl->select(                p         )
#define IHTMLTxtRange_pasteHTML(             p,a       ) (p)->lpVtbl->pasteHTML(             p,a       )
#define IHTMLTxtRange_moveToElementText(     p,a       ) (p)->lpVtbl->moveToElementText(     p,a       )
#define IHTMLTxtRange_setEndPoint(           p,a,b     ) (p)->lpVtbl->setEndPoint(           p,a,b     )
#define IHTMLTxtRange_compareEndPoints(      p,a,b,c   ) (p)->lpVtbl->compareEndPoints(      p,a,b,c   )
#define IHTMLTxtRange_findText(              p,a,b,c,d ) (p)->lpVtbl->findText(              p,a,b,c,d )
#define IHTMLTxtRange_moveToPoint(           p,a,b     ) (p)->lpVtbl->moveToPoint(           p,a,b     )
#define IHTMLTxtRange_getBookmark(           p,a       ) (p)->lpVtbl->getBookmark(           p,a       )
#define IHTMLTxtRange_moveToBookbark(        p,a,b     ) (p)->lpVtbl->moveToBookbark(        p,a,b     )
#define IHTMLTxtRange_queryCommandSupported( p,a,b     ) (p)->lpVtbl->queryCommandSupported( p,a,b     )
#define IHTMLTxtRange_queryCommandEnabled(   p,a,b     ) (p)->lpVtbl->queryCommandEnabled(   p,a,b     )
#define IHTMLTxtRange_queryCommandState(     p,a,b     ) (p)->lpVtbl->queryCommandState(     p,a,b     )
#define IHTMLTxtRange_queryCommandIndeterm(  p,a,b     ) (p)->lpVtbl->queryCommandIndeterm(  p,a,b     )
#define IHTMLTxtRange_queryCommandText(      p,a,b     ) (p)->lpVtbl->queryCommandText(      p,a,b     )
#define IHTMLTxtRange_queryCommandValue(     p,a,b     ) (p)->lpVtbl->queryCommandValue(     p,a,b     )
#define IHTMLTxtRange_execCommand(           p,a,b,c,d ) (p)->lpVtbl->execCommand(           p,a,b,c,d )
#define IHTMLTxtRange_execCommandShowHelp(   p,a,b     ) (p)->lpVtbl->execCommandShowHelp(   p,a,b     )


#define IHTMLElement_setAttribute(      p,a,b,c ) (p)->lpVtbl->setAttribute(      p,a,b,c )
#define IHTMLElement_getAttribute(      p,a,b,c ) (p)->lpVtbl->getAttribute(      p,a,b,c )
#define IHTMLElement_removeAttribute(   p,a,b,c ) (p)->lpVtbl->removeAttribute(   p,a,b,c )
#define IHTMLElement_put_className(         p,a ) (p)->lpVtbl->put_className(         p,a )
#define IHTMLElement_get_className(         p,a ) (p)->lpVtbl->get_className(         p,a )
#define IHTMLElement_put_id(                p,a ) (p)->lpVtbl->put_id(                p,a )
#define IHTMLElement_get_id(                p,a ) (p)->lpVtbl->get_id(                p,a )
#define IHTMLElement_get_tagName(           p,a ) (p)->lpVtbl->get_tagName(           p,a )
#define IHTMLElement_get_parentElement(     p,a ) (p)->lpVtbl->get_parentElement(     p,a )
#define IHTMLElement_get_style(             p,a ) (p)->lpVtbl->get_style(             p,a )
#define IHTMLElement_put_onhelp(            p,a ) (p)->lpVtbl->put_onhelp(            p,a )
#define IHTMLElement_get_onhelp(            p,a ) (p)->lpVtbl->get_onhelp(            p,a )
#define IHTMLElement_put_onclick(           p,a ) (p)->lpVtbl->put_onclick(           p,a )
#define IHTMLElement_get_onclick(           p,a ) (p)->lpVtbl->get_onclick(           p,a )
#define IHTMLElement_put_ondblclick(        p,a ) (p)->lpVtbl->put_ondblclick(        p,a )
#define IHTMLElement_get_ondblclick(        p,a ) (p)->lpVtbl->get_ondblclick(        p,a )
#define IHTMLElement_put_onkeydown(         p,a ) (p)->lpVtbl->put_onkeydown(         p,a )
#define IHTMLElement_get_onkeydown(         p,a ) (p)->lpVtbl->get_onkeydown(         p,a )
#define IHTMLElement_put_onkeyup(           p,a ) (p)->lpVtbl->put_onkeyup(           p,a )
#define IHTMLElement_get_onkeyup(           p,a ) (p)->lpVtbl->get_onkeyup(           p,a )
#define IHTMLElement_put_onkeypress(        p,a ) (p)->lpVtbl->put_onkeypress(        p,a )
#define IHTMLElement_get_onkeypress(        p,a ) (p)->lpVtbl->get_onkeypress(        p,a )
#define IHTMLElement_put_onmouseout(        p,a ) (p)->lpVtbl->put_onmouseout(        p,a )
#define IHTMLElement_get_onmouseout(        p,a ) (p)->lpVtbl->get_onmouseout(        p,a )
#define IHTMLElement_put_onmouseover(       p,a ) (p)->lpVtbl->put_onmouseover(       p,a )
#define IHTMLElement_get_onmouseover(       p,a ) (p)->lpVtbl->get_onmouseover(       p,a )
#define IHTMLElement_put_onmousemove(       p,a ) (p)->lpVtbl->put_onmousemove(       p,a )
#define IHTMLElement_get_onmousemove(       p,a ) (p)->lpVtbl->get_onmousemove(       p,a )
#define IHTMLElement_put_onmousedown(       p,a ) (p)->lpVtbl->put_onmousedown(       p,a )
#define IHTMLElement_get_onmousedown(       p,a ) (p)->lpVtbl->get_onmousedown(       p,a )
#define IHTMLElement_put_onmouseup(         p,a ) (p)->lpVtbl->put_onmouseup(         p,a )
#define IHTMLElement_get_onmouseup(         p,a ) (p)->lpVtbl->get_onmouseup(         p,a )
#define IHTMLElement_get_document(          p,a ) (p)->lpVtbl->get_document(          p,a )
#define IHTMLElement_put_title(             p,a ) (p)->lpVtbl->put_title(             p,a )
#define IHTMLElement_get_title(             p,a ) (p)->lpVtbl->get_title(             p,a )
#define IHTMLElement_put_language(          p,a ) (p)->lpVtbl->put_language(          p,a )
#define IHTMLElement_get_language(          p,a ) (p)->lpVtbl->get_language(          p,a )
#define IHTMLElement_put_onselectstart(     p,a ) (p)->lpVtbl->put_onselectstart(     p,a )
#define IHTMLElement_get_onselectstart(     p,a ) (p)->lpVtbl->get_onselectstart(     p,a )
#define IHTMLElement_scrollIntoView(        p,a ) (p)->lpVtbl->scrollIntoView(        p,a )
#define IHTMLElement_contains(            p,a,b ) (p)->lpVtbl->contains(            p,a,b )
#define IHTMLElement_get_source3Index(      p,a ) (p)->lpVtbl->get_source3Index(      p,a ) // [x] : MinGW typo
#define IHTMLElement_get_sourceIndex(       p,a ) (p)->lpVtbl->get_sourceIndex(       p,a )
#define IHTMLElement_get_recordNumber(      p,a ) (p)->lpVtbl->get_recordNumber(      p,a )
#define IHTMLElement_put_lang(              p,a ) (p)->lpVtbl->put_lang(              p,a )
#define IHTMLElement_get_lang(              p,a ) (p)->lpVtbl->get_lang(              p,a )
#define IHTMLElement_get_offsetLeft(        p,a ) (p)->lpVtbl->get_offsetLeft(        p,a )
#define IHTMLElement_get_offsetTop(         p,a ) (p)->lpVtbl->get_offsetTop(         p,a )
#define IHTMLElement_get_offsetWidth(       p,a ) (p)->lpVtbl->get_offsetWidth(       p,a )
#define IHTMLElement_get_offsetHeight(      p,a ) (p)->lpVtbl->get_offsetHeight(      p,a )
#define IHTMLElement_get_offsetParent(      p,a ) (p)->lpVtbl->get_offsetParent(      p,a )
#define IHTMLElement_put_innerHTML(         p,a ) (p)->lpVtbl->put_innerHTML(         p,a )
#define IHTMLElement_get_innerHTML(         p,a ) (p)->lpVtbl->get_innerHTML(         p,a )
#define IHTMLElement_put_innerText(         p,a ) (p)->lpVtbl->put_innerText(         p,a )
#define IHTMLElement_get_innerText(         p,a ) (p)->lpVtbl->get_innerText(         p,a )
#define IHTMLElement_put_outerHTML(         p,a ) (p)->lpVtbl->put_outerHTML(         p,a )
#define IHTMLElement_get_outerHTML(         p,a ) (p)->lpVtbl->get_outerHTML(         p,a )
#define IHTMLElement_put_outerText(         p,a ) (p)->lpVtbl->put_outerText(         p,a )
#define IHTMLElement_get_outerText(         p,a ) (p)->lpVtbl->get_outerText(         p,a )
#define IHTMLElement_insertAdjacentHTML(    p,a ) (p)->lpVtbl->insertAdjacentHTML(    p,a )
#define IHTMLElement_insertAdjacentText(    p,a ) (p)->lpVtbl->insertAdjacentText(    p,a )
#define IHTMLElement_get_parentTextEdit(    p,a ) (p)->lpVtbl->get_parentTextEdit(    p,a )
#define IHTMLElement_isTextEdit(            p,a ) (p)->lpVtbl->isTextEdit(            p,a )
#define IHTMLElement_click(                 p   ) (p)->lpVtbl->click(                 p   )
#define IHTMLElement_get_filters(           p,a ) (p)->lpVtbl->get_filters(           p,a )
#define IHTMLElement_put_ondragstart(       p,a ) (p)->lpVtbl->put_ondragstart(       p,a )
#define IHTMLElement_get_ondragstart(       p,a ) (p)->lpVtbl->get_ondragstart(       p,a )
#define IHTMLElement_toString(              p,a ) (p)->lpVtbl->toString(              p,a )
#define IHTMLElement_put_onbeforeupdate(    p,a ) (p)->lpVtbl->put_onbeforeupdate(    p,a )
#define IHTMLElement_get_onbeforeupdate(    p,a ) (p)->lpVtbl->get_onbeforeupdate(    p,a )
#define IHTMLElement_put_onafterupdate(     p,a ) (p)->lpVtbl->put_onafterupdate(     p,a )
#define IHTMLElement_get_onafterupdate(     p,a ) (p)->lpVtbl->get_onafterupdate(     p,a )
#define IHTMLElement_put_onerrorupdate(     p,a ) (p)->lpVtbl->put_onerrorupdate(     p,a )
#define IHTMLElement_get_onerrorupdate(     p,a ) (p)->lpVtbl->get_onerrorupdate(     p,a )
#define IHTMLElement_put_onrowexit(         p,a ) (p)->lpVtbl->put_onrowexit(         p,a )
#define IHTMLElement_get_onrowexit(         p,a ) (p)->lpVtbl->get_onrowexit(         p,a )
#define IHTMLElement_put_onrowenter(        p,a ) (p)->lpVtbl->put_onrowenter(        p,a )
#define IHTMLElement_get_onrowenter(        p,a ) (p)->lpVtbl->get_onrowenter(        p,a )
#define IHTMLElement_put_ondatasetchanged(  p,a ) (p)->lpVtbl->put_ondatasetchanged(  p,a )
#define IHTMLElement_get_ondatasetchanged(  p,a ) (p)->lpVtbl->get_ondatasetchanged(  p,a )
#define IHTMLElement_put_ondataavailable(   p,a ) (p)->lpVtbl->put_ondataavailable(   p,a )
#define IHTMLElement_get_ondataavailable(   p,a ) (p)->lpVtbl->get_ondataavailable(   p,a )
#define IHTMLElement_put_ondatasetcomplete( p,a ) (p)->lpVtbl->put_ondatasetcomplete( p,a )
#define IHTMLElement_get_ondatasetcomplete( p,a ) (p)->lpVtbl->get_ondatasetcomplete( p,a )
#define IHTMLElement_put_onfilterchange(    p,a ) (p)->lpVtbl->put_onfilterchange(    p,a )
#define IHTMLElement_get_onfilterchange(    p,a ) (p)->lpVtbl->get_onfilterchange(    p,a )
#define IHTMLElement_get_children(          p,a ) (p)->lpVtbl->get_children(          p,a )
#define IHTMLElement_get_all(               p,a ) (p)->lpVtbl->get_all(               p,a )


#define IHTMLLocation_assign( p,a ) (p)->lpVtbl->assign( p,a )


#define IHTMLWindow2_item(                   p,a,b ) (p)->lpVtbl->item(                   p,a,b )
#define IHTMLWindow2_get_length(             p,a   ) (p)->lpVtbl->get_length(             p,a   )
#define IHTMLWindow2_get_frames(             p,a   ) (p)->lpVtbl->get_frames(             p,a   )
#define IHTMLWindow2_put_defaultStatus(      p,a   ) (p)->lpVtbl->put_defaultStatus(      p,a   )
#define IHTMLWindow2_get_defaultStatus(      p,a   ) (p)->lpVtbl->get_defaultStatus(      p,a   )
#define IHTMLWindow2_put_status(             p,a   ) (p)->lpVtbl->put_status(             p,a   )
#define IHTMLWindow2_get_status(             p,a   ) (p)->lpVtbl->get_status(             p,a   )
#define IHTMLWindow2_setTimeout(       p,a,b,c,d   ) (p)->lpVtbl->setTimeout(       p,a,b,c,d   )
#define IHTMLWindow2_clearTimeout(           p,a   ) (p)->lpVtbl->clearTimeout(           p,a   )
#define IHTMLWindow2_alert(                  p,a   ) (p)->lpVtbl->alert(                  p,a   )
#define IHTMLWindow2_confirm(                p,a,b ) (p)->lpVtbl->confirm(                p,a,b )
#define IHTMLWindow2_prompt(                 p,a,b ) (p)->lpVtbl->prompt(                 p,a,b )
#define IHTMLWindow2_get_Image(              p,a   ) (p)->lpVtbl->get_Image(              p,a   )
#define IHTMLWindow2_get_location(           p,a   ) (p)->lpVtbl->get_location(           p,a   )
#define IHTMLWindow2_get_history(            p,a   ) (p)->lpVtbl->get_history(            p,a   )
#define IHTMLWindow2_close(                  p     ) (p)->lpVtbl->close(                  p     )
#define IHTMLWindow2_put_opener(             p,a   ) (p)->lpVtbl->put_opener(             p,a   )
#define IHTMLWindow2_get_opener(             p,a   ) (p)->lpVtbl->get_opener(             p,a   )
#define IHTMLWindow2_get_navigator(          p,a   ) (p)->lpVtbl->get_navigator(          p,a   )
#define IHTMLWindow2_put_name(               p,a   ) (p)->lpVtbl->put_name(               p,a   )
#define IHTMLWindow2_get_name(               p,a   ) (p)->lpVtbl->get_name(               p,a   )
#define IHTMLWindow2_get_parent(             p,a   ) (p)->lpVtbl->get_parent(             p,a   )
#define IHTMLWindow2_open(           p,a,b,c,d,e   ) (p)->lpVtbl->open(           p,a,b,c,d,e   )
#define IHTMLWindow2_get_self(               p,a   ) (p)->lpVtbl->get_self(               p,a   )
#define IHTMLWindow2_get_top(                p,a   ) (p)->lpVtbl->get_top(                p,a   )
#define IHTMLWindow2_get_window(             p,a   ) (p)->lpVtbl->get_window(             p,a   )
#define IHTMLWindow2_navigate(               p,a   ) (p)->lpVtbl->navigate(               p,a   )
#define IHTMLWindow2_put_onfocus(            p,a   ) (p)->lpVtbl->put_onfocus(            p,a   )
#define IHTMLWindow2_get_onfocus(            p,a   ) (p)->lpVtbl->get_onfocus(            p,a   )
#define IHTMLWindow2_put_onblur(             p,a   ) (p)->lpVtbl->put_onblur(             p,a   )
#define IHTMLWindow2_get_onblur(             p,a   ) (p)->lpVtbl->get_onblur(             p,a   )
#define IHTMLWindow2_put_onload(             p,a   ) (p)->lpVtbl->put_onload(             p,a   )
#define IHTMLWindow2_get_onload(             p,a   ) (p)->lpVtbl->get_onload(             p,a   )
#define IHTMLWindow2_put_onbeforeunload(     p,a   ) (p)->lpVtbl->put_onbeforeunload(     p,a   )
#define IHTMLWindow2_get_onbeforeunload(     p,a   ) (p)->lpVtbl->get_onbeforeunload(     p,a   )
#define IHTMLWindow2_put_onunload(           p,a   ) (p)->lpVtbl->put_onunload(           p,a   )
#define IHTMLWindow2_get_onunload(           p,a   ) (p)->lpVtbl->get_onunload(           p,a   )
#define IHTMLWindow2_put_onhelp(             p,a   ) (p)->lpVtbl->put_onhelp(             p,a   )
#define IHTMLWindow2_get_onhelp(             p,a   ) (p)->lpVtbl->get_onhelp(             p,a   )
#define IHTMLWindow2_put_onerror(            p,a   ) (p)->lpVtbl->put_onerror(            p,a   )
#define IHTMLWindow2_get_onerror(            p,a   ) (p)->lpVtbl->get_onerror(            p,a   )
#define IHTMLWindow2_put_onresize(           p,a   ) (p)->lpVtbl->put_onresize(           p,a   )
#define IHTMLWindow2_get_onresize(           p,a   ) (p)->lpVtbl->get_onresize(           p,a   )
#define IHTMLWindow2_put_onscroll(           p,a   ) (p)->lpVtbl->put_onscroll(           p,a   )
#define IHTMLWindow2_get_onscroll(           p,a   ) (p)->lpVtbl->get_onscroll(           p,a   )
#define IHTMLWindow2_get_document(           p,a   ) (p)->lpVtbl->get_document(           p,a   )
#define IHTMLWindow2_get_event(              p,a   ) (p)->lpVtbl->get_event(              p,a   )
#define IHTMLWindow2_get__newEnum(           p,a   ) (p)->lpVtbl->get__newEnum(           p,a   )
#define IHTMLWindow2_showModalDialog(  p,a,b,c,d   ) (p)->lpVtbl->showModalDialog(  p,a,b,c,d   )
#define IHTMLWindow2_showHelp(               p,a,b ) (p)->lpVtbl->showHelp(               p,a,b )
#define IHTMLWindow2_get_screen(             p,a   ) (p)->lpVtbl->get_screen(             p,a   )
#define IHTMLWindow2_get_Option(             p,a   ) (p)->lpVtbl->get_Option(             p,a   )
#define IHTMLWindow2_focus(                  p     ) (p)->lpVtbl->focus(                  p     )
#define IHTMLWindow2_get_closed(             p,a   ) (p)->lpVtbl->get_closed(             p,a   )
#define IHTMLWindow2_blur(                   p     ) (p)->lpVtbl->blur(                   p     )
#define IHTMLWindow2_scroll(                 p,a,b ) (p)->lpVtbl->scroll(                 p,a,b )
#define IHTMLWindow2_get_clientInformation(  p,a   ) (p)->lpVtbl->get_clientInformation(  p,a   )
#define IHTMLWindow2_setInterval(      p,a,b,c,d   ) (p)->lpVtbl->setInterval(      p,a,b,c,d   )
#define IHTMLWindow2_clearInterval(          p,a   ) (p)->lpVtbl->clearInterval(          p,a   )
#define IHTMLWindow2_put_offscreenBuffering( p,a   ) (p)->lpVtbl->put_offscreenBuffering( p,a   )
#define IHTMLWindow2_get_offscreenBuffering( p,a   ) (p)->lpVtbl->get_offscreenBuffering( p,a   )
#define IHTMLWindow2_execScript(             p,a,b ) (p)->lpVtbl->execScript(             p,a,b )
#define IHTMLWindow2_toString(               p,a   ) (p)->lpVtbl->toString(               p,a   )
#define IHTMLWindow2_scrollTo(               p,a,b ) (p)->lpVtbl->scrollTo(               p,a,b )
#define IHTMLWindow2_scrollBy(               p,a,b ) (p)->lpVtbl->scrollBy(               p,a,b )
#define IHTMLWindow2_moveTo(                 p,a,b ) (p)->lpVtbl->moveTo(                 p,a,b )
#define IHTMLWindow2_moveBy(                 p,a,b ) (p)->lpVtbl->moveBy(                 p,a,b )
#define IHTMLWindow2_resizeTo(               p,a,b ) (p)->lpVtbl->resizeTo(               p,a,b )
#define IHTMLWindow2_resizeBy(               p,a,b ) (p)->lpVtbl->resizeBy(               p,a,b )
#define IHTMLWindow2_get_external(           p,a   ) (p)->lpVtbl->get_external(           p,a   )


EXTERN_C const IID IID_IHTMLPluginsCollection;
#define INTERFACE IHTMLPluginsCollection
DECLARE_INTERFACE_(IHTMLPluginsCollection,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD( get_length )( THIS_ long*        ) PURE;
	STDMETHOD( refresh    )( THIS_ VARIANT_BOOL ) PURE;
};
#undef INTERFACE

EXTERN_C const IID IID_IHTMLOpsProfile;
#define INTERFACE IHTMLOpsProfile
DECLARE_INTERFACE_(IHTMLOpsProfile,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD( addRequest     )( THIS_ BSTR, VARIANT, VARIANT_BOOL* ) PURE;
	STDMETHOD( clearRequest   )( THIS ) PURE;
	STDMETHOD( doRequest      )( THIS_ VARIANT, VARIANT, VARIANT, VARIANT, VARIANT, VARIANT ) PURE;
	STDMETHOD( getAttribute   )( THIS_ BSTR, BSTR* ) PURE;
	STDMETHOD( setAttribute   )( THIS_ BSTR, BSTR, VARIANT, VARIANT_BOOL* ) PURE;
	STDMETHOD( commitChanges  )( THIS_ VARIANT_BOOL* ) PURE;
	STDMETHOD( addReadRequest )( THIS_ BSTR, VARIANT, VARIANT_BOOL* ) PURE;
	STDMETHOD( doReadRequest  )( THIS_ VARIANT, VARIANT, VARIANT, VARIANT, VARIANT, VARIANT ) PURE;
	STDMETHOD( doWriteRequest )( THIS_ VARIANT_BOOL* ) PURE;
};
#undef INTERFACE

EXTERN_C const IID IID_IHTMLMimeTypesCollection;
#define INTERFACE IHTMLMimeTypesCollection
DECLARE_INTERFACE_(IHTMLMimeTypesCollection,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD( get_length )( THIS_ long* ) PURE;
};
#undef INTERFACE

EXTERN_C const IID IID_IOmHistory;
#define INTERFACE IOmHistory
DECLARE_INTERFACE_(IOmHistory,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

    	STDMETHOD( get_length )( THIS_   short* ) PURE;
    	STDMETHOD( back       )( THIS_ VARIANT* ) PURE;
	STDMETHOD( forward    )( THIS_ VARIANT* ) PURE;
	STDMETHOD( go         )( THIS_ VARIANT* ) PURE;
};
#undef INTERFACE

#define IOmHistory_get_length( p,a ) (p)->lpVtbl->get_length( p,a )
#define IOmHistory_back(       p,a ) (p)->lpVtbl->back(       p,a )
#define IOmHistory_forward(    p,a ) (p)->lpVtbl->forward(    p,a )
#define IOmHistory_go(         p,a ) (p)->lpVtbl->go(         p,a )

EXTERN_C const IID IID_IOmNavigator;
#define INTERFACE IOmNavigator
DECLARE_INTERFACE_(IOmNavigator,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD( get_appCodeName     )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_appName         )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_appVersion      )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_userAgent       )( THIS_ BSTR* ) PURE;
	STDMETHOD( javaEnabled         )( THIS_ VARIANT_BOOL* ) PURE;
	STDMETHOD( taintEnabled        )( THIS_ VARIANT_BOOL* ) PURE;
	STDMETHOD( get_mimeTypes       )( THIS_ IHTMLMimeTypesCollection** ) PURE;
	STDMETHOD( get_plugins         )( THIS_ IHTMLPluginsCollection** ) PURE;
	STDMETHOD( get_cookieEnabled   )( THIS_ VARIANT_BOOL* ) PURE;
	STDMETHOD( get_opsProfile      )( THIS_ IHTMLOpsProfile** ) PURE;
	STDMETHOD( toString            )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_cpuClass        )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_systemLanguage  )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_browserLanguage )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_userLanguage    )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_platform        )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_appMinorVersion )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_connectionSpeed )( THIS_ BSTR* ) PURE;
	STDMETHOD( get_onLine          )( THIS_ VARIANT_BOOL* ) PURE;
	STDMETHOD( get_userProfile     )( THIS_ IHTMLOpsProfile** ) PURE;
};
#undef INTERFACE

EXTERN_C const IID IID_IHTMLEventObj;
#define INTERFACE IHTMLEventObj
DECLARE_INTERFACE_(IHTMLEventObj,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD( get_srcElement   )( THIS_ IHTMLElement** ) PURE;
	STDMETHOD( get_altKey       )( THIS_ VARIANT_BOOL*  ) PURE;
	STDMETHOD( get_ctrlKey      )( THIS_ VARIANT_BOOL*  ) PURE;
	STDMETHOD( get_shiftKey     )( THIS_ VARIANT_BOOL*  ) PURE;
	STDMETHOD( put_returnValue  )( THIS_ VARIANT        ) PURE;
	STDMETHOD( get_returnValue  )( THIS_ VARIANT*       ) PURE;
	STDMETHOD( put_cancelBubble )( THIS_ VARIANT_BOOL   ) PURE;
	STDMETHOD( get_cancelBubble )( THIS_ VARIANT_BOOL*  ) PURE;
	STDMETHOD( get_fromElement  )( THIS_ IHTMLElement** ) PURE;
	STDMETHOD( get_toElement    )( THIS_ IHTMLElement** ) PURE;
	STDMETHOD( put_keyCode      )( THIS_ long           ) PURE;
	STDMETHOD( get_keyCode      )( THIS_ long*          ) PURE;
	STDMETHOD( get_button       )( THIS_ long*          ) PURE;
	STDMETHOD( get_type         )( THIS_ BSTR*          ) PURE;
	STDMETHOD( get_qualifier    )( THIS_ BSTR*          ) PURE;
	STDMETHOD( get_reason       )( THIS_ long*          ) PURE;
	STDMETHOD( get_x            )( THIS_ long*          ) PURE;
	STDMETHOD( get_y            )( THIS_ long*          ) PURE;
	STDMETHOD( get_clientX      )( THIS_ long*          ) PURE;
	STDMETHOD( get_clientY      )( THIS_ long*          ) PURE;
	STDMETHOD( get_offsetX      )( THIS_ long*          ) PURE;
	STDMETHOD( get_offsetY      )( THIS_ long*          ) PURE;
	STDMETHOD( get_screenX      )( THIS_ long*          ) PURE;
	STDMETHOD( get_screenY      )( THIS_ long*          ) PURE;
	STDMETHOD( get_srcFilter    )( THIS_ IDispatch*     ) PURE;
};
#undef INTERFACE

#define IHTMLEventObj_get_srcElement(       p,a ) (p)->lpVtbl->get_srcElement(       p,a )
#define IHTMLEventObj_get_altKey(           p,a ) (p)->lpVtbl->get_altKey(           p,a )
#define IHTMLEventObj_get_ctrlKey(          p,a ) (p)->lpVtbl->get_ctrlKey(          p,a )
#define IHTMLEventObj_get_shiftKey(         p,a ) (p)->lpVtbl->get_shiftKey(         p,a )
#define IHTMLEventObj_put_returnValue(      p,a ) (p)->lpVtbl->put_returnValue(      p,a )
#define IHTMLEventObj_get_returnValue(      p,a ) (p)->lpVtbl->get_returnValue(      p,a )
#define IHTMLEventObj_put_cancelBubble(     p,a ) (p)->lpVtbl->put_cancelBubble(     p,a )
#define IHTMLEventObj_get_cancelBubble(     p,a ) (p)->lpVtbl->get_cancelBubble(     p,a )
#define IHTMLEventObj_get_fromElement(      p,a ) (p)->lpVtbl->get_fromElement(      p,a )
#define IHTMLEventObj_get_toElement(        p,a ) (p)->lpVtbl->get_toElement(        p,a )
#define IHTMLEventObj_put_keyCode(          p,a ) (p)->lpVtbl->put_keyCode(          p,a )
#define IHTMLEventObj_get_keyCode(          p,a ) (p)->lpVtbl->get_keyCode(          p,a )
#define IHTMLEventObj_get_button(           p,a ) (p)->lpVtbl->get_button(           p,a )
#define IHTMLEventObj_get_type(             p,a ) (p)->lpVtbl->get_type(             p,a )
#define IHTMLEventObj_get_qualifier(        p,a ) (p)->lpVtbl->get_qualifier(        p,a )
#define IHTMLEventObj_get_reason(           p,a ) (p)->lpVtbl->get_reason(           p,a )
#define IHTMLEventObj_get_x(                p,a ) (p)->lpVtbl->get_x(                p,a )
#define IHTMLEventObj_get_y(                p,a ) (p)->lpVtbl->get_y(                p,a )
#define IHTMLEventObj_get_clientX(          p,a ) (p)->lpVtbl->get_clientX(          p,a )
#define IHTMLEventObj_get_clientY(          p,a ) (p)->lpVtbl->get_clientY(          p,a )
#define IHTMLEventObj_get_offsetX(          p,a ) (p)->lpVtbl->get_offsetX(          p,a )
#define IHTMLEventObj_get_offsetY(          p,a ) (p)->lpVtbl->get_offsetY(          p,a )
#define IHTMLEventObj_get_screenX(          p,a ) (p)->lpVtbl->get_screenX(          p,a )
#define IHTMLEventObj_get_screenY(          p,a ) (p)->lpVtbl->get_screenY(          p,a )
#define IHTMLEventObj_get_srcFilter(        p,a ) (p)->lpVtbl->get_srcFilter(        p,a )

//EXTERN_C const IID IHTMLLocation;
#define INTERFACE IHTMLLocation
DECLARE_INTERFACE_(IHTMLLocation,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD( put_href     )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_href     )( THIS_ BSTR* ) PURE;
	STDMETHOD( put_protocol )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_protocol )( THIS_ BSTR* ) PURE;
	STDMETHOD( put_host     )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_host     )( THIS_ BSTR* ) PURE;
	STDMETHOD( put_hostname )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_hostname )( THIS_ BSTR* ) PURE;
	STDMETHOD( put_port     )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_port     )( THIS_ BSTR* ) PURE;
	STDMETHOD( put_pathname )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_pathname )( THIS_ BSTR* ) PURE;
	STDMETHOD( put_search   )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_search   )( THIS_ BSTR* ) PURE;
	STDMETHOD( put_hash     )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_hash     )( THIS_ BSTR* ) PURE;
	STDMETHOD( reload       )( THIS_ VARIANT_BOOL ) PURE;
	STDMETHOD( replace      )( THIS_ BSTR  ) PURE;
	STDMETHOD( assign       )( THIS_ BSTR  ) PURE;
	STDMETHOD( toString     )( THIS_ BSTR* ) PURE;
};
#undef INTERFACE


EXTERN_C const IID IID_IHTMLElement2;
#define INTERFACE IHTMLElement2
DECLARE_INTERFACE_(IHTMLElement2,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD( get_scopeName      )( THIS ) PURE;
	STDMETHOD( setCapture         )( THIS ) PURE;
	STDMETHOD( releaseCapture     )( THIS ) PURE;
	STDMETHOD( put_onlosecapture  )( THIS ) PURE;
	STDMETHOD( get_onlosecapture  )( THIS ) PURE;
	STDMETHOD( componentFromPoint )( THIS ) PURE;
	STDMETHOD( doScroll           )( THIS ) PURE;
	STDMETHOD( put_onscroll       )( THIS ) PURE;
	STDMETHOD( get_onscroll       )( THIS ) PURE;
	STDMETHOD( put_ondrag         )( THIS ) PURE;

	STDMETHOD( get_ondrag      )( THIS ) PURE;
	STDMETHOD( put_ondragend   )( THIS ) PURE;
	STDMETHOD( get_ondragend   )( THIS ) PURE;
	STDMETHOD( put_ondragenter )( THIS ) PURE;
	STDMETHOD( get_ondragenter )( THIS ) PURE;
	STDMETHOD( put_ondragover  )( THIS ) PURE;
	STDMETHOD( get_ondragover  )( THIS ) PURE;
	STDMETHOD( put_ondragleave )( THIS ) PURE;
	STDMETHOD( get_ondragleave )( THIS ) PURE;
	STDMETHOD( put_ondrop      )( THIS ) PURE;

	STDMETHOD( get_ondrop        )( THIS ) PURE;
	STDMETHOD( put_onbeforecut   )( THIS ) PURE;
	STDMETHOD( get_onbeforecut   )( THIS ) PURE;
	STDMETHOD( put_oncut         )( THIS ) PURE;
	STDMETHOD( get_oncut         )( THIS ) PURE;
	STDMETHOD( put_onbeforecopy  )( THIS ) PURE;
	STDMETHOD( get_onbeforecopy  )( THIS ) PURE;
	STDMETHOD( put_oncopy        )( THIS ) PURE;
	STDMETHOD( get_oncopy        )( THIS ) PURE;
	STDMETHOD( put_onbeforepaste )( THIS ) PURE;

	STDMETHOD( get_onbeforepaste     )( THIS ) PURE;
	STDMETHOD( put_onpaste           )( THIS ) PURE;
	STDMETHOD( get_onpaste           )( THIS ) PURE;
	STDMETHOD( get_currentStyle      )( THIS ) PURE;
	STDMETHOD( put_onpropertychange  )( THIS ) PURE;
	STDMETHOD( get_onpropertychange  )( THIS ) PURE;
	STDMETHOD( getClientRects        )( THIS ) PURE;
	STDMETHOD( getBoundingClientRect )( THIS ) PURE;
	STDMETHOD( setExpression         )( THIS ) PURE;
	STDMETHOD( getExpression         )( THIS ) PURE;

	STDMETHOD( removeExpression )( THIS ) PURE;
	STDMETHOD( put_tabIndex     )( THIS ) PURE;
	STDMETHOD( get_tabIndex     )( THIS ) PURE;
	STDMETHOD( put_accessKey    )( THIS ) PURE;
	STDMETHOD( get_accessKey    )( THIS ) PURE;
	STDMETHOD( put_onblur       )( THIS ) PURE;
	STDMETHOD( get_onblur       )( THIS ) PURE;
	STDMETHOD( put_onfocus      )( THIS ) PURE;
	STDMETHOD( get_onfocus      )( THIS ) PURE;
	STDMETHOD( put_onresize     )( THIS ) PURE;

	STDMETHOD( get_onresize     )( THIS ) PURE;
	STDMETHOD( blur             )( THIS ) PURE;
	STDMETHOD( addFilter        )( THIS ) PURE;
	STDMETHOD( removeFilter     )( THIS ) PURE;
	STDMETHOD( get_clientHeight )( THIS ) PURE;
	STDMETHOD( get_clientWidth  )( THIS ) PURE;
	STDMETHOD( get_clientTop    )( THIS ) PURE;
	STDMETHOD( get_clientLeft   )( THIS ) PURE;
	STDMETHOD( attachEvent      )( THIS ) PURE;
	STDMETHOD( detachEvent      )( THIS ) PURE;

	STDMETHOD( get_readyState         )( THIS ) PURE;
	STDMETHOD( put_onreadystatechange )( THIS ) PURE;
	STDMETHOD( get_onreadystatechange )( THIS ) PURE;
	STDMETHOD( put_onrowsdelete       )( THIS ) PURE;
	STDMETHOD( get_onrowsdelete       )( THIS ) PURE;
	STDMETHOD( put_onrowsinserted     )( THIS ) PURE;
	STDMETHOD( get_onrowsinserted     )( THIS ) PURE;
	STDMETHOD( put_oncellchange       )( THIS ) PURE;
	STDMETHOD( get_oncellchange       )( THIS ) PURE;
	STDMETHOD( put_dir                )( THIS ) PURE;

	STDMETHOD( get_dir            )( THIS ) PURE;
	STDMETHOD( createControlRange )( THIS ) PURE;
	STDMETHOD( get_scrollHeight   )( THIS ) PURE;
	STDMETHOD( get_scrollWidth    )( THIS ) PURE;
	STDMETHOD( put_scrollTop      )( THIS_ long v ) PURE;
	STDMETHOD( get_scrollTop      )( THIS ) PURE;
	STDMETHOD( put_scrollLeft     )( THIS_ long v ) PURE;
	STDMETHOD( get_scrollLeft     )( THIS ) PURE;
	STDMETHOD( clearAttributes    )( THIS ) PURE;
	STDMETHOD( mergeAttributes    )( THIS ) PURE;

	STDMETHOD( put_oncontextmenu     )( THIS ) PURE;
	STDMETHOD( get_oncontextmenu     )( THIS ) PURE;
	STDMETHOD( insertAdjacentElement )( THIS ) PURE;
	STDMETHOD( applyElement          )( THIS ) PURE;
	STDMETHOD( getAdjacentText       )( THIS ) PURE;
	STDMETHOD( replaceAdjacentText   )( THIS ) PURE;
	STDMETHOD( get_canHaveChildren   )( THIS ) PURE;
	STDMETHOD( addBehavior           )( THIS ) PURE;
	STDMETHOD( removeBehavior        )( THIS ) PURE;
	STDMETHOD( get_runtimeStyle      )( THIS ) PURE;

	STDMETHOD( get_behaviorUrns      )( THIS ) PURE;
	STDMETHOD( put_tagUrn            )( THIS ) PURE;
	STDMETHOD( get_tagUrn            )( THIS ) PURE;
	STDMETHOD( put_onbeforeeditfocus )( THIS ) PURE;
	STDMETHOD( get_onbeforeeditfocus )( THIS ) PURE;
	STDMETHOD( get_readyStateValue   )( THIS ) PURE;
	STDMETHOD( getElementsByTagName  )( THIS ) PURE;

};
#undef INTERFACE

EXTERN_C const IID IID_IHTMLStyleSheet;
#define INTERFACE IHTMLStyleSheet
DECLARE_INTERFACE_(IHTMLStyleSheet,IDispatch)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT*) PURE;

	STDMETHOD ( put_title )( THIS_ BSTR ) PURE;
	STDMETHOD ( get_title )( THIS_ BSTR* ) PURE;
	STDMETHOD ( get_parentStyleSheet )( THIS_ void** ) PURE;
	STDMETHOD ( get_owningElement )( THIS_ void** ) PURE;
	STDMETHOD ( put_disabled )( THIS_ VARIANT_BOOL ) PURE;
	STDMETHOD ( get_disabled )( THIS_ VARIANT_BOOL* ) PURE;
	STDMETHOD ( get_readOnly )( THIS_ VARIANT_BOOL* ) PURE;
	STDMETHOD ( get_imports )( THIS_ void** ) PURE;
	STDMETHOD ( put_href )( THIS_ BSTR ) PURE;
	STDMETHOD ( get_href )( THIS_ BSTR* ) PURE;
	STDMETHOD ( get_type )( THIS_ BSTR* ) PURE;
	STDMETHOD ( get_id )( THIS_ BSTR* ) PURE;
	STDMETHOD ( addImport )( THIS_ BSTR, long, long* ) PURE;
	STDMETHOD ( addRule )( THIS_ BSTR, BSTR, long, long* ) PURE;
	STDMETHOD ( removeImport )( THIS_ long ) PURE;
	STDMETHOD ( removeRule )( THIS_ long ) PURE;
	STDMETHOD ( put_media )( THIS_ BSTR ) PURE;
	STDMETHOD ( get_media )( THIS_ BSTR* ) PURE;
	STDMETHOD ( put_cssText )( THIS_ BSTR ) PURE;
	STDMETHOD ( get_cssText )( THIS_ BSTR* ) PURE;
	STDMETHOD ( get_rules )( THIS_ void** ) PURE;
};
#undef INTERFACE




// mshtmdid.h

#define DISPID_ONERROR                  ( DISPID_NORMAL_FIRST +  2 )
#define DISPID_ONLOAD                   ( DISPID_NORMAL_FIRST +  3 )
#define DISPID_ONUNLOAD                 ( DISPID_NORMAL_FIRST +  8 )
#define DISPID_ONSCROLL                 ( DISPID_NORMAL_FIRST + 14 )
#define DISPID_ONRESIZE                 ( DISPID_NORMAL_FIRST + 16 )
#define DISPID_ONBEFOREUNLOAD           ( DISPID_NORMAL_FIRST + 17 )
#define DISPID_ONCONTEXTMENU            ( DISPID_NORMAL_FIRST + 23 )
#define DISPID_ONBEFOREPRINT            ( DISPID_NORMAL_FIRST + 24 )
#define DISPID_ONAFTERPRINT             ( DISPID_NORMAL_FIRST + 25 )
#define DISPID_ONSTOP                   ( DISPID_NORMAL_FIRST + 26 )
#define DISPID_ONBEFOREEDITFOCUS        ( DISPID_NORMAL_FIRST + 27 )
#define DISPID_ONMOUSEWHEEL             ( DISPID_NORMAL_FIRST + 33 )
#define DISPID_ONBEFOREDEACTIVATE       ( DISPID_NORMAL_FIRST + 34 )
#define DISPID_ONSELECTIONCHANGE        ( DISPID_NORMAL_FIRST + 37 )
#define DISPID_ONACTIVATE               ( DISPID_NORMAL_FIRST + 44 )
#define DISPID_ONDEACTIVATE             ( DISPID_NORMAL_FIRST + 45 )
#define DISPID_ONBEFOREACTIVATE         ( DISPID_NORMAL_FIRST + 47 )
#define DISPID_ONFOCUSIN                ( DISPID_NORMAL_FIRST + 48 )
#define DISPID_ONFOCUSOUT               ( DISPID_NORMAL_FIRST + 49 )

#define DISPID_EVMETH_ONERROR           DISPID_ONERROR
#define DISPID_EVMETH_ONLOAD            DISPID_ONLOAD
#define DISPID_EVMETH_ONUNLOAD          DISPID_ONUNLOAD
#define DISPID_EVMETH_ONSCROLL          DISPID_ONSCROLL
#define DISPID_EVMETH_ONRESIZE          DISPID_ONRESIZE
#define DISPID_EVMETH_ONBEFOREUNLOAD    DISPID_ONBEFOREUNLOAD
//
#define DISPID_EVMETH_ONBEFOREPRINT     DISPID_ONBEFOREPRINT
#define DISPID_EVMETH_ONAFTERPRINT      DISPID_ONAFTERPRINT
//


#define DISPID_XOBJ_MIN                 0x80010000
#define DISPID_XOBJ_MAX                 0x8001FFFF
#define DISPID_XOBJ_BASE                DISPID_XOBJ_MIN

#define STDDISPID_XOBJ_ONBLUR           ( DISPID_XOBJ_BASE      )
#define STDDISPID_XOBJ_ONFOCUS          ( DISPID_XOBJ_BASE +  1 )
#define STDDISPID_XOBJ_ONMOUSEOVER      ( DISPID_XOBJ_BASE +  8 )
#define STDDISPID_XOBJ_ONMOUSEOUT       ( DISPID_XOBJ_BASE +  9 )
#define STDDISPID_XOBJ_ONHELP           ( DISPID_XOBJ_BASE + 10 )
#define STDDISPID_XOBJ_ONSELECTSTART    ( DISPID_XOBJ_BASE + 12 )
#define STDDISPID_XOBJ_ONPROPERTYCHANGE ( DISPID_XOBJ_BASE + 19 )
#define STDDISPID_XOBJ_ONCOPY           ( DISPID_XOBJ_BASE + 27 )
#define STDDISPID_XOBJ_ONPASTE          ( DISPID_XOBJ_BASE + 28 )
#define STDDISPID_XOBJ_ONBEFORECUT      ( DISPID_XOBJ_BASE + 29 )
#define STDDISPID_XOBJ_ONBEFORECOPY     ( DISPID_XOBJ_BASE + 30 )
#define STDDISPID_XOBJ_ONBEFOREPASTE    ( DISPID_XOBJ_BASE + 31 )

#define DISPID_EVMETH_ONBLUR            STDDISPID_XOBJ_ONBLUR
#define DISPID_EVMETH_ONFOCUS           STDDISPID_XOBJ_ONFOCUS
#define DISPID_EVMETH_ONMOUSEOVER       STDDISPID_XOBJ_ONMOUSEOVER
#define DISPID_EVMETH_ONMOUSEOUT        STDDISPID_XOBJ_ONMOUSEOUT
#define DISPID_EVMETH_ONHELP            STDDISPID_XOBJ_ONHELP
#define DISPID_EVMETH_ONSELECTSTART     STDDISPID_XOBJ_ONSELECTSTART
#define DISPID_EVMETH_ONPROPERTYCHANGE  STDDISPID_XOBJ_ONPROPERTYCHANGE
#define DISPID_EVMETH_ONBEFORECUT       STDDISPID_XOBJ_ONBEFORECUT


#define DISPID_READYSTATECHANGE     (-609)


#define DISPID_AMBIENT_DLCONTROL    (-5512)
#define DISPID_AMBIENT_USERAGENT    (-5513)

#define DLCTL_DLIMAGES              0x00000010
#define DLCTL_VIDEOS                0x00000020
#define DLCTL_BGSOUNDS              0x00000040
#define DLCTL_NO_SCRIPTS            0x00000080
#define DLCTL_NO_JAVA               0x00000100
#define DLCTL_NO_RUNACTIVEXCTLS     0x00000200
#define DLCTL_NO_DLACTIVEXCTLS      0x00000400
#define DLCTL_DOWNLOADONLY          0x00000800
#define DLCTL_NO_FRAMEDOWNLOAD      0x00001000
#define DLCTL_RESYNCHRONIZE         0x00002000
#define DLCTL_PRAGMA_NO_CACHE       0x00004000
#define DLCTL_FORCEOFFLINE          0x10000000
#define DLCTL_NO_CLIENTPULL         0x20000000
#define DLCTL_SILENT                0x40000000
#define DLCTL_OFFLINEIFNOTCONNECTED 0x80000000
#define DLCTL_OFFLINE               DLCTL_OFFLINEIFNOTCONNECTED




// mshtmhst.h

typedef struct _DOCHOSTUIINFO
{

	ULONG    cbSize;
	DWORD    dwFlags;
	DWORD    dwDoubleClick;
	OLECHAR *pchHostCss;
	OLECHAR *pchHostNS;

} DOCHOSTUIINFO;

typedef enum tagDOCHOSTUITYPE
{

	DOCHOSTUITYPE_BROWSE = 0,
	DOCHOSTUITYPE_AUTHOR = 1

} DOCHOSTUITYPE;


typedef enum tagDOCHOSTUIFLAG
{

	DOCHOSTUIFLAG_DIALOG                         = 0x00000001,
	DOCHOSTUIFLAG_DISABLE_HELP_MENU              = 0x00000002,
	DOCHOSTUIFLAG_NO3DBORDER                     = 0x00000004,
	DOCHOSTUIFLAG_SCROLL_NO                      = 0x00000008,
	DOCHOSTUIFLAG_DISABLE_SCRIPT_INACTIVE        = 0x00000010,
	DOCHOSTUIFLAG_OPENNEWWIN                     = 0x00000020,
	DOCHOSTUIFLAG_DISABLE_OFFSCREEN              = 0x00000040,
	DOCHOSTUIFLAG_FLAT_SCROLLBAR                 = 0x00000080,
	DOCHOSTUIFLAG_DIV_BLOCKDEFAULT               = 0x00000100,
	DOCHOSTUIFLAG_ACTIVATE_CLIENTHIT_ONLY        = 0x00000200,
	DOCHOSTUIFLAG_OVERRIDEBEHAVIORFACTORY        = 0x00000400,
	DOCHOSTUIFLAG_CODEPAGELINKEDFONTS            = 0x00000800,
	DOCHOSTUIFLAG_URL_ENCODING_DISABLE_UTF8      = 0x00001000,
	DOCHOSTUIFLAG_URL_ENCODING_ENABLE_UTF8       = 0x00002000,
	DOCHOSTUIFLAG_ENABLE_FORMS_AUTOCOMPLETE      = 0x00004000,
	DOCHOSTUIFLAG_ENABLE_INPLACE_NAVIGATION      = 0x00010000,
	DOCHOSTUIFLAG_IME_ENABLE_RECONVERSION        = 0x00020000,
	DOCHOSTUIFLAG_THEME                          = 0x00040000,
	DOCHOSTUIFLAG_NOTHEME                        = 0x00080000,
	DOCHOSTUIFLAG_NOPICS                         = 0x00100000,
	DOCHOSTUIFLAG_NO3DOUTERBORDER                = 0x00200000,
	DOCHOSTUIFLAG_DISABLE_EDIT_NS_FIXUP          = 0x00400000,
	DOCHOSTUIFLAG_LOCAL_MACHINE_ACCESS_CHECK     = 0x00800000,
	DOCHOSTUIFLAG_DISABLE_UNTRUSTEDPROTOCOL      = 0x01000000,
	DOCHOSTUIFLAG_HOST_NAVIGATES                 = 0x02000000,
	DOCHOSTUIFLAG_ENABLE_REDIRECT_NOTIFICATION   = 0x04000000,
	DOCHOSTUIFLAG_USE_WINDOWLESS_SELECTCONTROL   = 0x08000000,
	DOCHOSTUIFLAG_USE_WINDOWED_SELECTCONTROL     = 0x10000000,
	DOCHOSTUIFLAG_ENABLE_ACTIVEX_INACTIVATE_MODE = 0x20000000,
	DOCHOSTUIFLAG_DPI_AWARE                      = 0x40000000

} DOCHOSTUIFLAG;


EXTERN_C const IID IID_IDocHostUIHandler;
#define INTERFACE IDocHostUIHandler
DECLARE_INTERFACE_(IDocHostUIHandler,IUnknown)
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( ShowContextMenu       )( THIS_ DWORD, POINT*, IUnknown*, IDispatch* ) PURE;
	STDMETHOD( GetHostInfo           )( THIS_ DOCHOSTUIINFO* ) PURE;
	STDMETHOD( ShowUI                )( THIS_ DWORD, IOleInPlaceActiveObject*, IOleCommandTarget*, IOleInPlaceFrame*, IOleInPlaceUIWindow* ) PURE;
	STDMETHOD( HideUI                )( THIS ) PURE;
	STDMETHOD( UpdateUI              )( THIS ) PURE;
	STDMETHOD( EnableModeless        )( THIS_ BOOL ) PURE;
	STDMETHOD( OnDocWindowActivate   )( THIS_ BOOL ) PURE;
	STDMETHOD( OnFrameWindowActivate )( THIS_ BOOL ) PURE;
	STDMETHOD( ResizeBorder          )( THIS_ LPCRECT, IOleInPlaceUIWindow*, BOOL ) PURE;
	STDMETHOD( TranslateAccelerator  )( THIS_ LPMSG, const GUID*, DWORD ) PURE;
	STDMETHOD( GetOptionKeyPath      )( THIS_ LPOLESTR*, DWORD ) PURE;
	STDMETHOD( GetDropTarget         )( THIS_ IDropTarget*, IDropTarget** ) PURE;
	STDMETHOD( GetExternal           )( THIS_ IDispatch** ) PURE;
	STDMETHOD( TranslateUrl          )( THIS_ DWORD, OLECHAR*, OLECHAR** ) PURE;
	STDMETHOD( FilterDataObject      )( THIS_ IDataObject*, IDataObject** ) PURE;
};
#undef INTERFACE

#define IDocHostUIHandler_QueryInterface(        p, a,b       ) (p)->lpVtbl->QueryInterface(p,a,b)

#define IDocHostUIHandler_ShowContextMenu(       p, a,b,c,d   ) (p)->lpVtbl->ShowContextMenu(p,a,b,c,d)
#define IDocHostUIHandler_GetHostInfo(           p, a         ) (p)->lpVtbl->GetHostInfo(p,a)
#define IDocHostUIHandler_ShowUI(                p, a,b,c,d,e ) (p)->lpVtbl->ShowUI(p,a,b,c,d,e)
#define IDocHostUIHandler_HideUI(                p            ) (p)->lpVtbl->HideUI(p)
#define IDocHostUIHandler_UpdateUI(              p            ) (p)->lpVtbl->UpdateUI(p)
#define IDocHostUIHandler_EnableModeless(        p, a         ) (p)->lpVtbl->EnableModeless(p,a)
#define IDocHostUIHandler_OnDocWindowActivate(   p, a         ) (p)->lpVtbl->OnDocWindowActivate(p,a)
#define IDocHostUIHandler_OnFrameWindowActivate( p, a         ) (p)->lpVtbl->OnFrameWindowActivate(p,a)
#define IDocHostUIHandler_ResizeBorder(          p, a,b,c     ) (p)->lpVtbl->ResizeBorder(p,a,b,c)
#define IDocHostUIHandler_TranslateAccelerator(  p, a,b,c     ) (p)->lpVtbl->TranslateAccelerator(p,a,b,c)
#define IDocHostUIHandler_GetOptionKeyPath(      p, a,b       ) (p)->lpVtbl->GetOptionKeyPath(p,a,b)
#define IDocHostUIHandler_GetDropTarget(         p, a,b       ) (p)->lpVtbl->GetDropTarget(p,a,b)
#define IDocHostUIHandler_GetExternal(           p, a         ) (p)->lpVtbl->GetExternal(p,a)
#define IDocHostUIHandler_TranslateUrl(          p, a,b,c     ) (p)->lpVtbl->TranslateUrl(p,a,b,c)
#define IDocHostUIHandler_FilterDataObject(      p, a,b       ) (p)->lpVtbl->FilterDataObject(p,a,b)


EXTERN_C const IID IID_ICustomDoc;
#define INTERFACE ICustomDoc
DECLARE_INTERFACE_(ICustomDoc,IUnknown)
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( SetUIHandler )( THIS_ IDocHostUIHandler* ) PURE;
};
#undef INTERFACE

#define ICustomDoc_SetUIHandler( p, a ) (p)->lpVtbl->SetUIHandler( p, a )




// urlmon.h

#define Uri_CREATE_ALLOW_RELATIVE                 0x00000001
#define Uri_CREATE_ALLOW_IMPLICIT_WILDCARD_SCHEME 0x00000002
#define Uri_CREATE_ALLOW_IMPLICIT_FILE_SCHEME     0x00000004
#define Uri_CREATE_NOFRAG                         0x00000008
#define Uri_CREATE_NO_CANONICALIZE                0x00000010
#define Uri_CREATE_FILE_USE_DOS_PATH              0x00000020
#define Uri_CREATE_DECODE_EXTRA_INFO              0x00000040
#define Uri_CREATE_NO_DECODE_EXTRA_INFO           0x00000080
#define Uri_CREATE_CANONICALIZE                   0x00000100
#define Uri_CREATE_CRACK_UNKNOWN_SCHEMES          0x00000200
#define Uri_CREATE_NO_CRACK_UNKNOWN_SCHEMES       0x00000400
#define Uri_CREATE_PRE_PROCESS_HTML_URI           0x00000800
#define Uri_CREATE_NO_PRE_PROCESS_HTML_URI        0x00001000
#define Uri_CREATE_IE_SETTINGS                    0x00002000
#define Uri_CREATE_NO_IE_SETTINGS                 0x00004000
#define Uri_CREATE_NO_ENCODE_FORBIDDEN_CHARACTERS 0x00008000

#define URLPOLICY_ALLOW     0x00
#define URLPOLICY_QUERY     0x01
#define URLPOLICY_DISALLOW  0x03

#define URLACTION_COOKIES_ENABLED 0x00001A10

#define SET_FEATURE_ON_THREAD              0x00000001
#define SET_FEATURE_ON_PROCESS             0x00000002
#define SET_FEATURE_IN_REGISTRY            0x00000004
#define SET_FEATURE_ON_THREAD_LOCALMACHINE 0x00000008
#define SET_FEATURE_ON_THREAD_INTRANET     0x00000010
#define SET_FEATURE_ON_THREAD_TRUSTED      0x00000020
#define SET_FEATURE_ON_THREAD_INTERNET     0x00000040
#define SET_FEATURE_ON_THREAD_RESTRICTED   0x00000080


typedef enum _tagINTERNETFEATURELIST
{

	FEATURE_OBJECT_CACHING                 =  0,
	FEATURE_ZONE_ELEVATION                 =  1,
	FEATURE_MIME_HANDLING                  =  2,
	FEATURE_MIME_SNIFFING                  =  3,
	FEATURE_WINDOW_RESTRICTIONS            =  4,
	FEATURE_WEBOC_POPUPMANAGEMENT          =  5,
	FEATURE_BEHAVIORS                      =  6,
	FEATURE_DISABLE_MK_PROTOCOL            =  7,
	FEATURE_LOCALMACHINE_LOCKDOWN          =  8,
	FEATURE_SECURITYBAND                   =  9,
	FEATURE_RESTRICT_ACTIVEXINSTALL        = 10,
	FEATURE_VALIDATE_NAVIGATE_URL          = 11,
	FEATURE_RESTRICT_FILEDOWNLOAD          = 12,
	FEATURE_ADDON_MANAGEMENT               = 13,
	FEATURE_PROTOCOL_LOCKDOWN              = 14,
	FEATURE_HTTP_USERNAME_PASSWORD_DISABLE = 15,
	FEATURE_SAFE_BINDTOOBJECT              = 16,
	FEATURE_UNC_SAVEDFILECHECK             = 17,
	FEATURE_GET_URL_DOM_FILEPATH_UNENCODED = 18,
	FEATURE_TABBED_BROWSING                = 19,
	FEATURE_SSLUX                          = 20,
	FEATURE_DISABLE_NAVIGATION_SOUNDS      = 21,
	FEATURE_DISABLE_LEGACY_COMPRESSION     = 22,
	FEATURE_FORCE_ADDR_AND_STATUS          = 23,
	FEATURE_XMLHTTP                        = 24,
	FEATURE_DISABLE_TELNET_PROTOCOL        = 25,
	FEATURE_FEEDS                          = 26,
	FEATURE_BLOCK_INPUT_PROMPTS            = 27,
	FEATURE_ENTRY_COUNT                    = 28

} INTERNETFEATURELIST;


typedef enum PUAF
{

	PUAF_DEFAULT                = 0x0000,
	PUAF_NOUI                   = 0x0001,
	PUAF_ISFILE                 = 0x0002,
	PUAF_WARN_IF_DENIED         = 0x0004,
	PUAF_FORCEUI_FOREGROUND     = 0x0008,
	PUAF_CHECK_TIFS             = 0x0010,
	PUAF_DONTCHECKBOXINDIALOG   = 0x0020,
	PUAF_TRUSTED                = 0x0040,
	PUAF_ACCEPT_WILDCARD_SCHEME = 0x0080,
	PUAF_ENFORCERESTRICTED      = 0x0100

} PUAF;

EXTERN_C const IID IID_IInternetSecurityManager;
#define INTERFACE IInternetSecurityManager
DECLARE_INTERFACE_(IInternetSecurityManager,IUnknown)
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( SetSecuritySite   )( THIS_ void* ) PURE;
	STDMETHOD( GetSecuritySite   )( THIS_ void** ) PURE;
	STDMETHOD( MapUrlToZone      )( THIS_ LPCWSTR, DWORD*, DWORD ) PURE;
	STDMETHOD( GetSecurityId     )( THIS_ LPCWSTR, BYTE*, DWORD*, DWORD_PTR ) PURE;
	STDMETHOD( ProcessUrlAction  )( THIS_ LPCWSTR, DWORD, BYTE*, DWORD, DWORD*, DWORD, PUAF, DWORD ) PURE;
	STDMETHOD( QueryCustomPolicy )( THIS_ LPCWSTR, REFGUID, BYTE**, DWORD*, BYTE*, DWORD, DWORD ) PURE;
	STDMETHOD( SetZoneMapping    )( THIS_ DWORD, LPCWSTR, DWORD ) PURE;
	STDMETHOD( GetZoneMappings   )( THIS_ DWORD, void**, DWORD ) PURE;
};
#undef INTERFACE


#define IInternetSecurityManager_QueryInterface(    p, a,b             ) (p)->lpVtbl->QueryInterface(p,a,b)
#define IInternetSecurityManager_AddRef(            p                  ) (p)->lpVtbl->AddRef(p)
#define IInternetSecurityManager_Release(           p                  ) (p)->lpVtbl->Release(p)
#define IInternetSecurityManager_SetSecuritySite(   p, a               ) (p)->lpVtbl->SetSecuritySite(p,a)
#define IInternetSecurityManager_GetSecuritySite(   p, a               ) (p)->lpVtbl->GetSecuritySite(p,a)
#define IInternetSecurityManager_MapUrlToZone(      p, a,b,c           ) (p)->lpVtbl->MapUrlToZone(p,a,b,c)
#define IInternetSecurityManager_GetSecurityId(     p, a,b,c,d         ) (p)->lpVtbl->GetSecurityId(p,a,b,c,d)
#define IInternetSecurityManager_ProcessUrlAction(  p, a,b,c,d,e,f,g,h ) (p)->lpVtbl->ProcessUrlAction(p,a,b,c,d,e,f,g,h)
#define IInternetSecurityManager_QueryCustomPolicy( p, a,b,c,d,e,f,g   ) (p)->lpVtbl->QueryCustomPolicy(p,a,b,c,d,e,f,g)
#define IInternetSecurityManager_SetZoneMapping(    p, a,b,c           ) (p)->lpVtbl->SetZoneMapping(p,a,b,c)
#define IInternetSecurityManager_GetZoneMappings(   p, a,b,c           ) (p)->lpVtbl->GetZoneMappings(p,a,b,c)


#define SID_SInternetSecurityManager IID_IInternetSecurityManager

HRESULT CoInternetCreateSecurityManager( IServiceProvider *pSP, IInternetSecurityManager **ppSM, DWORD dwReserved );




#endif // _H_NONNON_WIN32_COM_PATCH

